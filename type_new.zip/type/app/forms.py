from django import forms
from .models import Job

class jobform(forms.Form):
    name = forms.CharField(max_length=10, required=False)


# class jobform(forms.ModelForm):
#     class meta:
#         model = Job
#         fields = "__all__"