
# imports
import matplotlib.pyplot as plt
import numpy as np
import wave, sys

# shows the sound waves
def visualize(path: str):

        # reading the audio file
        raw = wave.open('/home/rdp/Downloads/Recordings-Tank/STEREO/FOLDER 1/FOLDER01/ZOOM0140.WAV')
        
        # reads all the frames
        # -1 indicates all or max frames
        signal = raw.readframes(-1)
        signal = np.frombuffer(signal, dtype ="int16")
        
        # gets the frame rate
        f_rate = raw.getframerate()

        # to Plot the x-axis in seconds
        # you need get the frame rate
        # and divide by size of your signal
        # to create a Time Vector
        # spaced linearly with the size
        # of the audio file
        time = np.linspace(
            0, # start
            len(signal) / f_rate,
            num = len(signal)
        )
        print(time)
        print(len(signal) / f_rate)
        print(len(signal))

        # defining an array
        xs = [-3000, 3000]
        
        # using matplotlib to plot
        # creates a new figure
        plt.figure(1)
        
        # plt.vlines(x = 39.25, ymin = 25, ymax = max(xs), colors = 'green')
        
        # title of the plot
        plt.title("TANK")
        
        # label of x-axis
        plt.xlabel("Time")
        
        # actual plotting
        plt.plot(time, signal,color="blue")
        # shows the plot
        # in new window
        
        # Saving the figure.
        plt.savefig("TANK.png")
        plt.show()

        
        # Saving figure by changing parameter values
        # plt.savefig("output1", facecolor='y', bbox_inches="tight",
        #             pad_inches=0.3, transparent=True)
        # you can also save
        # the plot using
        # plt.savefig('filename')


if __name__ == "__main__":

	# gets the command line Value
	path = sys.argv[0]

	visualize(path)
