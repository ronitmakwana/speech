

import screeninfo
import cv2



im = cv2.imread('data (copy).jpeg')
height, width, channels = im.shape
print(width,height)

im = cv2.resize(im,(int(height/2),int(width/2)))
cv2.imwrite('neww.png',im)
