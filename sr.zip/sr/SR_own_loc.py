
from PyQt5 import QtCore, QtGui, QtWidgets
from pyproj import Transformer
from geojson import Point, Feature, FeatureCollection
import sqlite3
from datetime import datetime as dt
import geojson
from PyQt5 import QtCore, QtGui, QtWidgets,QtWebEngineWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# get_sr_loc = ''


detection = dict()

class Ui_Dialog_new(object):
    def setupUi(self, Dialog):
        reg_ex_1 = QRegExp("[0-9]+[0-9]{,2}")
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 306)
        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setGeometry(QtCore.QRect(30, 230, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 60, 101, 31))
        self.label.setObjectName("label")
        # self.comboBox = QtWidgets.QComboBox(Dialog)
        self.dialoglineedit = QtWidgets.QLineEdit(Dialog)

        self.dialoglineedit.setGeometry(QtCore.QRect(160, 60, 211, 31))
        self.dialoglineedit.setAcceptDrops(True)
        self.dialoglineedit.setValidator(QRegExpValidator(reg_ex_1))
        # self.dialoglineedit.setValidator(QIntValidator(1,99999999, self))


        # self.dialoglineedit.setCurrentText("")
        self.dialoglineedit.setObjectName("comboBox")
        self.dialoglineedit_2 = QtWidgets.QLineEdit(Dialog)
        self.dialoglineedit_2.setGeometry(QtCore.QRect(160, 110, 211, 25))
        self.dialoglineedit_2.setValidator(QRegExpValidator(reg_ex_1))
        # self.dialoglineedit_2.setValidator(QIntValidator(1,99999999, self))


        # self.dialoglineedit_2.setCurrentText("")
        self.dialoglineedit_2.setObjectName("comboBox_2")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(20, 100, 121, 31))
        self.label_2.setObjectName("label_2")
        # self.textEdit = QtWidgets.QTextEdit(Dialog)
        # self.textEdit.setGeometry(QtCore.QRect(160, 140, 211, 41))
        # self.textEdit.setObjectName("textEdit")
        # self.label_3 = QtWidgets.QLabel(Dialog)
        # self.label_3.setGeometry(QtCore.QRect(30, 140, 121, 31))
        # self.label_3.setObjectName("label_3")

        self.retranslateUi(Dialog)
        self.buttonBox.accepted.connect(self.Target_Info)
        self.buttonBox.accepted.connect(Dialog.accept)
        self.buttonBox.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

  
     
    def Target_Info(self):

        print("Easting : {0}".format(self.dialoglineedit.text()))
        print("Northing : {0}".format(self.dialoglineedit_2.text()))
        # print("Remarks : {0}".format(self.textEdit.toPlainText()))
        loc_h = []
        detection['Easting']=self.dialoglineedit.text()
        detection['Northing']=self.dialoglineedit_2.text()
        detection['date']= dt.now().strftime('%d-%m-%Y')
        detection['time'] = dt.now().strftime('%H:%M:%S')
        detection['type']='BFSR SR Own Location'


        transformer = Transformer.from_crs(24379, 4326)
        point_43279 = [(float(detection['Easting']), float(detection['Northing']))]
        point_4326 = transformer.itransform(point_43279)
        my_string = str(*point_4326)
        coord = "POINT " + my_string.replace(',', '')
        coord_str = my_string[1:-1]
        lon, lat = float(coord_str.split(',')[0]), float(coord_str.split(',')[1])
        long_lat = Point((lat, lon))
        print(lon,lat)


        loc_h.append(Feature(geometry=long_lat, properties=detection))
        newgeojson = FeatureCollection(loc_h)

        
        with open('/home/bisag/Music/ARMY/BFSR_SR/templates/BFSR_SR_own_location.geojson','w') as files:
            print(newgeojson)

            files.write(geojson.dumps(newgeojson, sort_keys=True))

        # global get_sr_loc
        # get_sr_loc = 'yes'

    # def get_data_11(self):
        
    #     return get_sr_loc

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "BFSR SR Info"))
        self.label.setText(_translate("Dialog", "  Easting:"))
        self.label_2.setText(_translate("Dialog", " Northing:"))
        # self.label_3.setText(_translate("Dialog", " Remarks :"))

# if __name__ == "__main__":
#     import sys
#     app = QtWidgets.QApplication(sys.argv)
#     Dialog = QtWidgets.QDialog()
#     ui = Ui_Dialog_new()
#     ui.setupUi(Dialog)
#     Dialog.show()
#     sys.exit(app.exec_())




