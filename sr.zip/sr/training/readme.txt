CHANGE_LOG

(Each version text is changes added to it from the previous version while keeping other things same)


Version 1:

Model: bfsr_cnn_librosa_chiloda.pt

- model, training and dataset configs are same as previous (phase 1)
- input audio clip size is set to 5s
- Data is taken from 100,000 newly annotated files 
- model has 3 output classes
- loudness normalization is turned OFF (same as phase_1)
- class name to index mapping is {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
- dataset mean: [78.74880732380272], std: [26.040366700751193]


Version 2:

Model: bfsr_cnn_librosa_chiloda_v2.pt

- model and dataset configs are modified from version 1
    - parameters to generate mel spectrogram is updated, resulting in different input resolution
    - spectrogram mask augment set to OFF
    - pad and truncate strategy is updated
    - model architecture is updated according to different input size
- added lr scheduler
- dataset mean: [51.55220031738281], std: [20.79323387145996]


Version 3:

Model: bfsr_cnn_librosa_chiloda_v3.pt

- model configs are modified from version 2 (output layer)
    - heavy vehicle and light vehicle classes merged into a vehicle class
    - new class name to index mapping is {"VEHICLE": 0, "GROUP OF MEN": 1}
    - generated data_y_v3.pkl from data_y.pkl by simply updating label IDs according to aforementioned

