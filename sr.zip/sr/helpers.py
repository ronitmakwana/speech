import cv2
import matplotlib.pyplot as plt
import numpy as np
from geojson import Point, Feature, FeatureCollection
import geojson
from datetime import datetime as dt
from PIL import Image, ImageEnhance
import uuid
import json
import sqlite3
locations = []


def does_contain(text, keywords):
    for k, v in keywords.items():
        if k in text:
            return k, v


def clear_target_locations():
    print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Clearing targets")
    global locations
    locations_updated = []
    for feature in locations:
        if feature["properties"]["type"] == "BFSR":
            locations_updated.append(feature)
            break
    feature_collection = FeatureCollection(locations_updated)
        
    # with open('geojsonurl/detections.geojson', 'w') as f:
    #     f.write(geojson.dumps(feature_collection, sort_keys=True)) 
    locations = locations_updated

def validate_estng_nrthng_detections(easting: str, northing: str):
    easting = easting.strip()
    northing = northing.strip()
    if len(easting) != 7 or len(northing) != 7:
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Invalid length | Easting: {easting}, Northing: {northing}")
        return (-1, None, None)
    easting_first_five_check = all([letter.isdigit() for letter in easting[:5]])
    northing_first_five_check = all([letter.isdigit() for letter in northing[:5]])
    if easting_first_five_check and northing_first_five_check:
        easting_last_two_check = all([letter.isdigit() for letter in easting[5:]])
        northing_last_two_check = all([letter.isdigit() for letter in northing[5:]])
        
        if not easting_last_two_check:
            easting[5:7] = "00"
        if not northing_last_two_check:
            northing[5:7] = "00"
        return 0, easting, northing
    else:
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Invalid value(s) | Easting: {easting}, Northing: {northing}")
        return -1, None, None
    
        

def get_bfsr_location(img, easyocr, transformer):
    print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Processing started for BFSR location")
    img = cv2.resize(img, (640, 420))

    keywords = {
        'easting': 1,
        'thing': 1,  # northing
    }
    bfsr_locations = []
    global locations

    try:
        im = Image.open(r"/home/bisag/Music/ARMY/BFSR_SR/logs/bfsr_location.png")
        # left,top,right,bottom = 537,235,622,309  # all
        # left,top,right,bottom = 536,275,622,289  # range
        left,top,right,bottom = 330,287,410,400 #all final

        im1 = im.crop((left, top, right, bottom))
        # im1.show()
        im1.save('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')


        # get image
        filepath = "/home/bisag/Music/ARMY/BFSR_SR/00.bmp"
        img = Image.open(filepath)
        
        # get width and height
        width = img.width
        height = img.height


        image = Image.open('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')
        # print(f"Original size : {image.size}") # 5464x3640

        sunset_resized = image.resize((width*5, height*5))
        sunset_resized.save('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')

        im = Image.open('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')
        enhancer = ImageEnhance.Contrast(im)


        factor = 1.0 #increase contrast
        im_output = enhancer.enhance(factor)
        im_output.save('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')

        im = Image.open('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')
        enhancer = ImageEnhance.Brightness(im)


        factor = 1.0 #increase contrast
        im_output = enhancer.enhance(factor)
        im_output.save('/home/bisag/Music/ARMY/BFSR_SR/00.bmp')


        Keyword = {'easting': 1,'northing': 1,'lat': 1,'long': 1}

        # im_output.show()

        results = easyocr.readtext('/home/bisag/Music/ARMY/BFSR_SR/00.bmp',allowlist='0123456789', paragraph=True)
        # print(results) 
        list_data = []
        for i in results:
            Data_EN = i[1].replace(' ','').replace('\x0c','')
            Data_EN = i[1].split("\n")
            list_data.append(Data_EN)
        print(list_data)

        east = list_data[0][0]
        while len(east) < 7:
            east = east + '0'
        Keyword['easting'] = int(east)
        north = list_data[1][0]
        while len(north) < 7:
            north = north + '0'
        Keyword['northing'] = int(north)
        lat = list_data[2][0]
        lat = lat.replace(' ', '')
        Keyword['lat'] = float(lat)
        long = list_data[3][0]
        long = lat.replace(' ', '')
        Keyword['long'] = float(long)

        Keyword['date'] = dt.now().strftime('%d/%m/%Y')

        Keyword['time'] = dt.now().strftime('%H:%M:%S')


        print('Keyword',Keyword)

        # geojson = {"type": "FeatureCollection", "features": []}
        # # geo = dic['features'][0]['geometry']['coordinates']
        # # print(dic)
        
        # with open('geojsonurl/BFSR_location_EN.json','w') as files:
        #     # print(dic)
        #     json.dump(Keyword,files)
        # point_43279 = [(float(Keyword['easting']), float(Keyword['north']))]
        # point_4326 = transformer.itransform(point_43279)
        # point_4326 = (tuple(reversed(x)) for x in point_4326) 
        # # print(point_4326)
        # # # geo.append(*point_4326)
        # # print(type(geo))
        # for i in point_4326:
        #     print(i)
        #     ab = 0
        #     for j in i:
        #         if ab == 0:
        #             Keyword['Esting'] = float(j)
        #             ab = 1
        #         elif ab == 1:
        #             Keyword['Northing'] = float(j)
        #         else:
        #             pass
        #         print(j)
        #         # geo.append(j)
        # # print(type(geo_Zone))
        # # geo_Zone.append(list_Zone)
        # dic = {'type': 'FeatureCollection','features':[{'type':'Feature','properties':[],'geometry': {'type': 'Point','coordinates': [Keyword['Esting'],Keyword['Northing']]}}]}
        # print('dic',dic)
        # # dp = json.dumps(dic
        # # print('dp',dp)
        # # filename = 'geojsonurl/file.geojson'
        # # with open(filename,'wb+') as f:
        #         #     f.write(str(dp))
          
        # with open('geojsonurl/BFSR_Location.geojson','w') as files:
        #     # print(dic)
        #     json.dump(dic,files)
        #     # print('geo',geo)
        # #*****************************
        '''
        results = easyocr.readtext(np.array(img))

        detections = {}
        i = 0

        while i < len(results):
            box = results[i][0]
            text = results[i][1].lower().strip()
            ret = does_contain(text, keywords)
            if ret is not None:
                detections[ret[0]] = results[i + ret[1]][1].lower().strip()
                i += ret[1]
            i += 1
        if 'easting' not in detections or 'thing' not in detections:
            fp = f"logs/{str(uuid.uuid4())}.png"
            cv2.imwrite(fp, img)
            print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Couldn't extract easting/northing {detections} | check file at {fp}")
            return -1
        ret, easting, northing = validate_estng_nrthng_detections(detections['easting'], detections['thing'])
        if ret == -1:
            fp = f"logs/{str(uuid.uuid4())}.png"
            cv2.imwrite(fp, img)
            print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | check file at {fp}")
            return -1
        
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Detected Easting: {easting}, Northing: {northing}")
        
        bfsr_locations = []
        global locations
        point_43279 = [(float(easting), float(northing))]
        point_4326 = transformer.itransform(point_43279)
        my_string = str(*point_4326)
        coord = "POINT " + my_string.replace(',', '')
        coord_str = my_string[1:-1]
        lon, lat = float(coord_str.split(',')[0]), float(coord_str.split(',')[1])
        # p_geom = Point((lat, lon))
        '''
       

        p_geom = Point((72.715595, 23.234998))
        bfsr_locations.append(Feature(geometry=p_geom, properties={"type": "BFSR","subtype": "BFSR", "time": dt.now().strftime('%d/%m/%Y %H:%M:%S')}))
        locations.append(Feature(geometry=p_geom, properties={"type": "BFSR","subtype": "BFSR", "time": dt.now().strftime('%d/%m/%Y %H:%M:%S')}))
        
        feature_collection = FeatureCollection(bfsr_locations)
        
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | BFSR location: {p_geom}")
        # with open('geojsonurl/bfsr.geojson', 'w') as f:
        #     f.write(geojson.dumps(feature_collection, sort_keys=True))  
        # with open('geojsonurl/detections.geojson', 'w') as f:
        #     f.write(geojson.dumps(feature_collection, sort_keys=True))
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Completed processing for BFSR location")
        return Keyword
    except Exception as ex:
        fp = f"/home/bisag/Music/ARMY/BFSR_SR/logs/{str(uuid.uuid4())}.png"
        # cv2.imwrite(fp, img)
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Exception {ex} | check file at {fp}")
        return -1

def get_target_location(img,target_type, easyocr, transformer):
    print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S:%f')[:-3]} | Processing started for Target location")
    img = cv2.resize(img, (400, 660))

    global locations

    keywords = {
        'easting': 1,
        'thing': 1,  # northing
        'range': 1,
        'az': 1,
        'speed': 2,
        'heading': 1,
        'type': 'Target'
 
    }
    # dict={''}
    # from BFSR_Simple_GUI_v2 import var
    
   
    
    # conn = sqlite3.connect('BFSR_PRED.db')
    # cursor = conn.cursor()
    # command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
    # cursor.execute(command)
    # comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
    # cursor.execute(comm)
    # cursor.close()
    # conn.commit()
    # command = "select target_name from pred order by id desc"
    # cursor.execute(command)
    # result = cursor.fetchone()
    # target = result[0]
    # print(var)
    # dict['target']=result[0]
    # print(dict)
    # json_data = json.dumps(dict)
    # print(json_data)
    


    try:
        results = easyocr.readtext(np.array(img))

        detections = {}
        i = 0
        Keyword = {'easting': 1,'northing': 1,'range': 1,'azimuth': 1,'speed': 1,'heading': 1}
        # im = Image.open(r"logs/target_location.png")
        # # left,top,right,bottom = 537,235,622,309  # all
        # # left,top,right,bottom = 536,275,622,289  # range
        # left,top,right,bottom = 535,235,618,346 #all final

        # im1 = im.crop((left, top, right, bottom))
        # # im1.show()
        # im1.save('00.bmp')


        # # get image
        # filepath = "00.bmp"
        # img = Image.open(filepath)
        
        # # get width and height
        # width = img.width
        # height = img.height


        # image = Image.open('00.bmp')
        # # print(f"Original size : {image.size}") # 5464x3640

        # sunset_resized = image.resize((width*5, height*5))
        # sunset_resized.save('00.bmp')

        # im = Image.open('00.bmp')
        # enhancer = ImageEnhance.Contrast(im)


        # factor = 1.0 #increase contrast
        # im_output = enhancer.enhance(factor)
        # im_output.save('00.bmp')

        # im = Image.open('00.bmp')
        # enhancer = ImageEnhance.Brightness(im)


        # factor = 1.0 #increase contrast
        # im_output = enhancer.enhance(factor)
        # im_output.save('00.bmp')



        # # im_output.show() 
        # results = easyocr.readtext('00.bmp',allowlist='0123456789', paragraph=True)
        # # print(results)
        # list_data = []
        # for i in results:
        #     Data_EN = i[1].replace(' ','').replace('\x0c','')
        #     Data_EN = i[1].split("\n")
        #     list_data.append(Data_EN)
        # # print(list_data)

        # east = list_data[0][0]
        # while len(east) < 7:
        #     east = east + '0'
        # Keyword['easting'] = int(east)
        # north = list_data[1][0]
        # while len(north) < 7:
        #     north = north + '0'
        # Keyword['north'] = int(north)
        # Keyword['range'] = float(list_data[2][0])
        # Keyword['az'] = float(list_data[3][0])
        # Keyword['speed'] = float(list_data[4][0])
        # Keyword['heading'] = float(list_data[5][0])
        # # print('No Data Found') 
        # print('Keyword',Keyword)
        
              
        # with open('geojsonurl/Targat_location_EN.json','w') as files:
        #     # print(dic)
        #     json.dump(Keyword,files)
        # # it = iter(Prop)
        # # Prop = dict(zip(it, it))
        # # # print('res_dct',Prop)
        
        # # it = iter(list_EN)
        # # res_dct = dict(zip(it, it))
        # # print('res_dct',res_dct)
        # geojson = {"type": "FeatureCollection", "features": []}
       
        # dic = {'type': 'FeatureCollection','features':[{'type':'Feature','properties':{'range':Keyword['range'],'azimuth':Keyword['az'],'speed':Keyword['speed'],'heading':Keyword['heading']},'geometry': {'type': 'Point','coordinates': []}}]}
        # geo = dic['features'][0]['geometry']['coordinates']
        # print(dic)
        # point_43279 = [(float(Keyword['easting']), float(Keyword['north']))]
        # point_4326 = transformer.itransform(point_43279)
        # point_4326 = (tuple(reversed(x)) for x in point_4326) 
        # # print(point_4326)
        # # # geo.append(*point_4326)
        # # print(type(geo))
        # for i in point_4326:
        #     # print(i)
        #     for j in i:
        #         # print(j)
        #         geo.append(j)
        # # print(type(geo_Zone))
        # # geo_Zone.append(list_Zone)
        # print('dic',dic)
        # # dp = json.dumps(dic)
        # # print('dp',dp)
        # # filename = 'geojsonurl/file.geojson'
        # # with open(filename,'wb+') as f:
        #         #     f.write(str(dp))
          
        # with open('geojsonurl/Targat_location.geojson','w') as files:
        #     # print(dic)
        #     json.dump(dic,files)
        #     # print('geo',geo)
        # ##############################  
            

        is_valid = False
        for i in range(len(results)):
            text = results[i][1].lower().strip()
            if text == "tracking mode":
                is_valid = True
                break
        if not is_valid:
            fp = f"/home/bisag/Music/ARMY/BFSR_SR/logs/{str(uuid.uuid4())}.png"
            cv2.imwrite(fp, img)
            print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Tracking Mode not found in frame, check {fp}") 
            return -1

        while i < len(results):
            box = results[i][0]
            text = results[i][1].lower().strip()
            print(text,'=-=-=-=-=-=-')
            ret = does_contain(text, keywords)
            if ret is not None:
                detections[ret[0]] = results[i + ret[1]][1].lower().strip()
                i += ret[1]
            i += 1
            
        if 'easting' not in detections or 'thing' not in detections:
            fp = f"/home/bisag/Music/ARMY/BFSR_SR/logs/{str(uuid.uuid4())}.png"
            cv2.imwrite(fp, img)
            print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Couldn't extract easting/northing {detections} | check file at {fp}")
            return -1
        ret, easting, northing = validate_estng_nrthng_detections(detections['easting'], detections['thing'])
        if ret == -1:
            fp = f"/home/bisag/Music/ARMY/BFSR_SR/logs/{str(uuid.uuid4())}.png"
            cv2.imwrite(fp, img)
            print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | check file at {fp}")
            return -1
        
        
        
        #with open('/home/bisag/Music/ARMY/BFSR_SR/file_audio.txt','r') as fs:
         #   target = fs.read()
          #  # list_of_target.append(target)
           # # target_type = list_of_target[-1]
            #print(target)
        
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Detected Easting: {easting}, Northing: {northing}")
        detections['easting'] = easting
        detections['northing'] = northing
        point_43279 = [(float(easting), float(northing))]
        point_4326 = transformer.itransform(point_43279)
        my_string = str(*point_4326)
        coord = "POINT " + my_string.replace(',', '')
        coord_str = my_string[1:-1]
        lon, lat = float(coord_str.split(',')[0]), float(coord_str.split(',')[1])
        p_geom = Point((lat, lon))
        detections['type']= "Target Location"
        detections['subtype'] = ''
        detections['date'] = dt.now().strftime('%d/%m/%Y')

        detections['time'] = dt.now().strftime('%H:%M:%S')
#        detections['target_type'] = target
        print(detections)
        locations.append(Feature(geometry=p_geom, properties=detections))
        feature_collection = FeatureCollection(locations)
        # print(detections,'=======')
                
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Detections for target: {detections}")
        # list_of_target=[]
        
    
                
            
        # with open('geojsonurl/Targat_location_EN.json','w') as files:
        #     print(feature_collection,'=-=-=-=-=-=-')
        #     json.dumps(feature_collection,files)
        #     print('')
        print(feature_collection,'=--=-=-')
        with open('/home/bisag/Music/ARMY/BFSR_SR/templates/Target_location1.geojson', 'w') as f:
            f.write(geojson.dumps(feature_collection, sort_keys=True))  
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S:%f')[:-3]} | Completed processing for target location")
        return detections
    except Exception as ex:
        fp = f"/home/bisag/Music/ARMY/BFSR_SR/logs/{str(uuid.uuid4())}.png"
        # cv2.imwrite(fp, img)
        print(f"{dt.now().strftime('%d/%m/%Y %H:%M:%S')} | Exception {ex} | check file at {fp}")
        return -1

