# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
# from email.mime import audio
import os, sys,time,cv2,easyocr
# import threading
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer
from helpers import get_bfsr_location, get_target_location, clear_target_locations
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph
import warnings
import faulthandler
import sqlite3
import pyaudio
from collections import Counter
import torch
# from matplotlib import pyplot as plt
from training.model import AudioCNNClassifier, infer
from torchvision.transforms import Normalize
# from qtpy import QtCore, QtGui, QtWidgets
from datetime import datetime as dt
import wave
import matplotlib.image
from PyQt5.QtWebEngineWidgets import QWebEngineView 

from PyQt5 import QtCore, QtGui, QtWidgets,QtWebEngineWidgets



from file import Ui_Dialog_map as Map
import webbrowser

from SR_own_loc import Ui_Dialog_new as OWN_Loc


from newtgt import Ui_dialog as Cap_tgt
from PyQt5.QtCore import QTime,QDate
from PyQt5.QtWidgets import QApplication, QWidget,QTableWidget, QTableWidgetItem,QVBoxLayout,QHeaderView


from PyQt5.QtWidgets import *

import glob
from natsort import natsorted
import pandas as pd
# import wave
# import matplotlib.pyplot as plt

FS = 44100 #Hz
CHUNKSZ = 1024 #samples
input_audio = 0

device = 'cpu'
desired_sr = 16000
max_audio_duration_ms = 5000

checkpoint = torch.load("/home/bisagn/Music/ARMY/BFSR_SR/training/models/bfsr_cnn_librosa_chiloda.pt", map_location=device)
#checkpoint = torch.load("training/models/bfsr_cnn_librosa_chiloda_v3.pt", map_location=device)
cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])

prediction_history = ['','','','','']
            
prediction_history_save = ''
date_pred = ''
time_pred = ''
prediction_print = ''   
prediction_ocr = ''                        


swap_wav = 'Waveform'


rec_list = []
recording = 'Stop'

screen_record_onoff = False 
audio_record_onoff = True


zoom_image = 0

faulthandler.enable()

warnings.filterwarnings("ignore")

class Dialog(QtWidgets.QDialog, Cap_tgt):
    def __init__(self,easting,northing,date,time,az,range,speed,prediction_ocr,heading,parent=None):
        super(Dialog,self).__init__(parent)
        self.setupUi(self)
        self.lineEdit_7.setText(easting)
        self.lineEdit_8.setText(northing)
        self.lineEdit_2.setText(range)
        self.lineEdit_9.setText(az)
        self.lineEdit_10.setText(speed)
        self.lineEdit_11.setText(heading)
        self.textEdit.setText(prediction_ocr)
        # self.lineEdit_9.setText(time)
        # date = date.split('/')
        # print(date)
        # d = QDate(int(date[2]),int(date[1]),int(date[0]))
        # self.date.setDate(d)
        # time = time.split(':')
        # print(time)

        # time = QTime(int(time[0]),int(time[1]),int(time[2]))

        # self.time.setTime(time)
        date = date.split('-')
        # print(date)
        d = QDate(int(date[2]),int(date[1]),int(date[0]))
        self.dateEdit.setDate(d)
        time = time.split(':')
        # print(time)

        time = QTime(int(time[0]),int(time[1]),int(time[2]))

        self.timeEdit.setTime(time)
        
        if prediction_ocr == 'No sound or Noise':
            self.comboBox.setCurrentIndex(0)
        elif prediction_ocr == 'LIGHT VEHICLE':
            self.comboBox.setCurrentIndex(1)
        elif prediction_ocr == 'HEAVY VEHICLE':
            self.comboBox.setCurrentIndex(2)
        elif prediction_ocr == 'GROUP OF MEN':
            self.comboBox.setCurrentIndex(3)
            
class SR_OWN_LOC(QtWidgets.QDialog, OWN_Loc):
    def __init__(self,easting,northing,date,time,parent=None):
        super(SR_OWN_LOC,self).__init__(parent)
        self.setupUi(self)
        self.dialoglineedit.setText(easting)
        self.dialoglineedit_2.setText(northing)


class Ui_Dialog_map(QtWidgets.QDialog, Map):
    def __init__(self,parent=None):
        super(Ui_Dialog_map,self).__init__(parent)
        self.setupUi(self)


class PhotoViewer(QtWidgets.QGraphicsView):
    photoClicked = QtCore.pyqtSignal(QtCore.QPoint)
    def __init__(self, parent):
        super(PhotoViewer, self).__init__(parent)
        self._zoom = 0
        self._empty = True
        self._scene = QtWidgets.QGraphicsScene(self)
        self._photo = QtWidgets.QGraphicsPixmapItem()
        self._scene.addItem(self._photo)
        self.setScene(self._scene)
        self.setTransformationAnchor(QtWidgets.QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QtWidgets.QGraphicsView.AnchorUnderMouse)
        self.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        # self.setBackgroundBrush(QtGui.QBrush(QtGui.QColor(30, 30, 30)))
        self.setFrameShape(QtWidgets.QFrame.NoFrame)

    def hasPhoto(self):
        
        return not self._empty

    def fitInView(self, scale=True):
        
        rect = QtCore.QRectF(self._photo.pixmap().rect())
        if not rect.isNull():
            self.setSceneRect(rect)
            if self.hasPhoto():
                unity = self.transform().mapRect(QtCore.QRectF(0, 0, 1, 1))
                self.scale(1 / unity.width(), 1 / unity.height())
                viewrect = self.viewport().rect()
                scenerect = self.transform().mapRect(rect)
                factor = min(viewrect.width() / scenerect.width(),
                             viewrect.height() / scenerect.height())
                self.scale(factor, factor)
            self._zoom = 0

    def setPhoto(self, pixmap=None):
        global zoom_image
        
        self._zoom = 0
        if pixmap and not pixmap.isNull():
            self._empty = False
            self.setDragMode(QtWidgets.QGraphicsView.ScrollHandDrag)
            self._photo.setPixmap(pixmap)
        else:
            self._empty = True
            self.setDragMode(QtWidgets.QGraphicsView.NoDrag)
            self._photo.setPixmap(QtGui.QPixmap())
        # self.fitInView()
        
        if self.hasPhoto():
            # print(self._zoom)
            if zoom_image > 0:
                # print(zoom_image)
                pass
                
                # for j in range(0,len(zoom_image)):
                #     # factor_new = zoom_image * 1.25
                #     factor_new = 1.25
                    # self.scale(factor_new, factor_new)
            elif self._zoom == 0:
                self.fitInView()
            else:
                
                
                # self.fitInView()
                zoom_image = 0

                
        
    def wheelEvent(self, event):
        
        global zoom_image
        if self.hasPhoto():
            if event.angleDelta().y() > 0:
                factor = 1.25
                self._zoom += 1
            else:
                factor = 0.8
                self._zoom -= 1
            if self._zoom > 0:
                self.scale(factor, factor)
            elif self._zoom == 0:
                self.fitInView()
            else:
                self._zoom = 0
            zoom_image = self._zoom
            
    


    # def toggleDragMode(self):
        
    #     if self.dragMode() == QtWidgets.QGraphicsView.ScrollHandDrag:
    #         self.setDragMode(QtWidgets.QGraphicsView.NoDrag)
    #     elif not self._photo.pixmap().isNull():
    #         self.setDragMode(QtWidgets.QGraphicsView.ScrollHandDrag)

    # def mousePressEvent(self, event):
        
    #     if self._photo.isUnderMouse():
    #         self.photoClicked.emit(self.mapToScene(event.pos()).toPoint())
    #     super(PhotoViewer, self).mousePressEvent(event)


class MicThread(QtCore.QThread):
    sig = QtCore.Signal(bytes)
    def __init__(self, sc):
        super(MicThread, self).__init__()
        self.sc = sc
        self.sig.connect(self.sc.append)
        self.running = True

    def run(self):
        global prediction_print,y,prediction_ocr,recording
        self.updatesPerSecond = 5
        self.chunksRead = 0
        self.device = device
        self.rate = 44100
        self.chunk = self.rate  # gets replaced automatically
        self.buffer = None
        self.inference_window_size_secs = 5 # Change depending on the model
        self.preds = []
        self.probs = []
        self.keep_preds_size = (12 * self.rate) / self.chunk
        self.final_prediction = ''
        #class_to_idx = {"heavy vehicle": 0, "light vehicle": 1}
        #class_to_idx = {"Heavy Vehicle": 0, "crawling man": 1, "group of men": 2, "single walking man": 3}
        class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        # class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1}
        #class_to_idx = {"VEHICLE": 0, "GROUP OF MEN": 1}
        self.idx_to_class = {v: k for k, v in class_to_idx.items()}
        self.frames = []
        try:
            while self.running:
                self.keepRecording = True  # set this to False later to terminate stream
                self.dataa = None  # will fill up with threaded recording data
                self.fft = None
                self.dataFiltered = None 
                readdata = self.sc.stream.read(self.sc.CHUNK, exception_on_overflow=False)

                if recording == 'Start':
                    # print(recording)
                    rec_list.append(readdata)

                self.sig.emit(readdata)
                y = np.fromstring(readdata, 'int16')
                # self.sc.emit(y)
                self.dataa = np.frombuffer(readdata, dtype=np.int16).astype(np.float32, order='C') / 32768.0
                self.frames.append(readdata)
                

                if self.buffer is not None:
                    self.buffer = np.hstack([self.buffer, self.dataa])
                else:
                    self.buffer = self.dataa
                if self.buffer.shape[0] > (self.rate * self.inference_window_size_secs):
                    self.buffer = self.buffer[-(self.rate * self.inference_window_size_secs):]
                # plt.hist(self.data, bins=1000)
                # plt.show()
                nb_recent_samples = int(1 * self.rate)
                # if (np.logical_and(-.003 <= self.buffer[-nb_recent_samples:],
                #                    self.buffer[-nb_recent_samples:] <= .003).sum() / self.buffer[-nb_recent_samples:].shape[
                #         0]) > .8:
                if np.max(self.buffer[-nb_recent_samples:]) - np.min(self.buffer[-nb_recent_samples:]) <= 0.03:
                    self.final_prediction = 'No sound or Noise'
                    self.preds.clear()
                    self.probs.clear()
                    prediction_print = self.final_prediction
                    prediction_ocr = self.final_prediction
                    prediction_print = str(prediction_print) +' Date & Time : '+  str(dt.now().strftime('%d/%m/%Y %H:%M:%S'))
                    prediction_history.append(prediction_print)
                    
                    if len(prediction_history) == 6:
                        prediction_history.pop(0)
                        
                    
                       
                    # prediction_history[-5:]
                    
                # TODO: detect noise function
                else:
                    if self.buffer.shape[0] == (self.rate * self.inference_window_size_secs):
                        # input_tensor = torch.from_numpy(self.buffer).unsqueeze(0).type(torch.float32)
                        input_audio = np.copy(self.buffer)
                        prob, pred_id = infer(classifier=cnn,
                                            data=input_audio,
                                            input_sr=self.rate,
                                            desired_sr=desired_sr,
                                            max_audio_duration_ms=max_audio_duration_ms,
                                            normalize=Normalize(mean=[51.55220031738281], std=[20.79323387145996]))
                        if len(self.preds) == self.keep_preds_size:
                            del self.preds[0]
                            del self.probs[0]

                        # print(self.preds)
                        self.preds.append(pred_id)
                        self.probs.append(prob)

                        frqs = Counter(self.preds)
                        final_pred_id = frqs.most_common(1)[0][0]
                        cnt = 0
                        avg = 0
                        for i, prob in enumerate(self.probs):
                            if self.preds[i] == final_pred_id:
                                avg += self.probs[i]
                                cnt += 1
                        avg_prob = (avg / cnt) * 100
                        self.final_prediction = f"{self.idx_to_class[pred_id]} : {int(prob*100)}%"
                        prediction_print = self.final_prediction
                        conn = sqlite3.connect('/home/bisagn/Music/ARMY/BFSR_SR/BFSR_SR.db')
                        cursor = conn.cursor()
                        prediction_print = str(prediction_print) +' Date & Time : '+ str(dt.now().strftime('%d/%m/%Y %H:%M:%S'))
                        prediction_history.append(prediction_print)
                        prediction_history_save = str(self.final_prediction)
                        date_pred =   str(dt.now().strftime('%d/%m/%Y'))
                        time_pred = str(dt.now().strftime('%H:%M:%S'))
                        insert_tab = "INSERT INTO MR(PRED,DATE,TIME)VALUES ('"+str(prediction_history_save)+"','"+str(date_pred)+"','"+str(time_pred)+"')"
                        cursor.execute(insert_tab)
                        conn.commit()
                        if len(prediction_history) == 6:
                            prediction_history.pop(0)
                        prediction_ocr = f"{self.idx_to_class[pred_id]}"
                        
                       
                        self.buffer = None

        except:
            (type, value, traceback) = sys.exc_info()
            sys.stdout.write(str(type))
            sys.stdout.write(str(value))
            sys.stdout.write(str(traceback.format_exc()))
            
    def stop(self):
        sys.stdout.write('THREAD STOPPED')
        self.running = False
    def close(self):
        self.stream.stop_stream()
        self.stream.close()
        self.p.terminate()


class MicrophoneRecorder():
    def __init__(self, signal):
        self.signal = signal

    def read(self):
        self.signal.emit(y)

    def close(self):
        self.stream.stop_stream()
        self.stream.close()
        self.p.terminate()


class StreamController(QtGui.QMainWindow):
    def __init__(self):
        super(StreamController, self).__init__()
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        # self.FORMAT = pyaudio.paInt16
        
    def setup_stream(self):
        self.audio = pyaudio.PyAudio()
        
        
        # self.stream = self.earac.stream_startac(self)
        self.stream = self.audio.open(format=pyaudio.paInt16,  channels=1, rate=self.RATE, 
                            input=True, frames_per_buffer=self.CHUNK)
        self.micthread = MicThread(self)
        self.micthread.start()
        

    def append(self, vals):
        vals = np.frombuffer(vals, 'int16')
        c = self.CHUNK
        self.data[:-c] = self.data[c:]
        self.data[-c:] = vals
        
    # def breakdown_stream(self):
    #     self.micthread.terminate()
    #     self.stream.stop_stream()
    #     self.stream.close()
    #     self.audio.terminate()
    #     loop = QtCore.QEventLoop()
    #     QtCore.QTimer.singleShot(400, loop.quit)
    #     loop.exec_()
class Thread(QThread):
    sig = QtCore.Signal(bytes)
    changePixmap = pyqtSignal(QImage)

    def __init__(self, width, height):
        super().__init__()
        self.width, self.height = width, height

    def run(self):
        # self._stop_event = threading.Event()
        global kill_set_img_th
        # cap = cv2.VideoCapture(0)
        # cap = cv2.VideoCapture('target_location.png')
        cap = cv2.VideoCapture('/home/bisagn/Music/ARMY/BFSR_SR/cdu_screen_video.mp4')
        while not kill_set_img_th:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = np.copy(frame)
                current_frame = cv2.resize(current_frame, (640, 480))
                try:
                    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                except:
                    pass
                h, w, ch = img.shape
                bytes_per_line = ch * w
                qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
                p = qt_img.scaled(self.width, self.height, QtCore.Qt.IgnoreAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)
            else:
                break
        cap.release()

    # def stop(self):
    #     self._stop_event.set()

'''
def capture_target_location(_easyocr, transformer):
    # For image of size 640x480
    global kill_ocr_thread
    roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
    while not kill_ocr_thread:
        if ocr_on_target_screen_flag:
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            get_target_location(roi, _easyocr, transformer)
            # time.sleep(15)

'''
    # self.grFFT.plotItem.showGrid(True, True, 0.7)
    #     self.grPCM.plotItem.showGrid(True, True, 0.7)
grFFT = 0
grPCM = 0
var = ""
# conn = sqlite3.connect('BFSR_PRED.db')
class Ui_MainWindow(QWidget):
    read_collected = QtCore.pyqtSignal(np.ndarray)
    def __init__(self):
        super(Ui_MainWindow,self).__init__()
        # self.img = pyqtgraph.ImageItem()
        # self.addItem(self.img)

        self.img_array = np.zeros((150, int(CHUNKSZ/2+1)))
        

        # # bipolar colormap
        # pos = np.array([0., 1., 0.5, 0.25, 0.75])
        # color = np.array([[0,255,255,255], [255,255,0,255], [0,0,0,255], (0, 0, 255, 255), (255, 0, 0, 255)], dtype=np.ubyte)
        # cmap = pyqtgraph.ColorMap(pos, color)
        # lut = cmap.getLookupTable(0.0, 1.0, 256)

        # # set colormap
        # self.img.setLookupTable(lut)
        # self.img.setLevels([-50,40])

        # setup the correct scaling for y-axis
        # freq = np.arange((CHUNKSZ/2)+1)/(float(CHUNKSZ)/FS)
        # yscale = 1.0/(self.img_array.shape[1]/freq[-1])
        # self.img.scale((1./FS)*CHUNKSZ, yscale)

        # self.setLabel('left', 'Frequency', units='Hz')

        # prepare window for later use
        self.win = np.hanning(CHUNKSZ)
        # cv2.imwrite('111.png',self.win)
        
        # self.show()
   

    def setupUi(self, MainWindow):
        global grFFT
        global grPCM
        MainWindow.setObjectName("MainWindow")

        screen_size = app.primaryScreen().size()
        # self.window_width = screen_size.width() - 100
        # self.window_height = screen_size.height() - 100
        
        self.window_width = screen_size.width()
        self.window_height = screen_size.height()-100

        MainWindow.setFixedSize(self.window_width, self.window_height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.keyPressEvent = self.keyPressEvent
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(10, 20, 201, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.target_capture_button = QtWidgets.QPushButton(self.centralwidget)
        self.target_capture_button.setGeometry(QtCore.QRect(210, 20, 141, 25))
        self.target_capture_button.setObjectName("pushButton_2")
        # self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)


        #880,920
        
        self.target_type = ""

        vid_width = self.window_width - 20
        vid_height = self.window_height - 80
        # print(str(self.window_width)+'width')
        # print(str(self.window_height)+'height')
        # self.cdu_screen_label.setGeometry(QtCore.QRect(10, 60,
        #                                                vid_width/2,
        #                                                vid_height))
        # self.cdu_screen_label.setObjectName("graphicsView")
        # self.cdu_screen_label.setScaledContents(True)
        
        
        
        self.viewer = PhotoViewer(self.centralwidget)
        
        
        self.viewer.setGeometry(QtCore.QRect(10, 60,int(vid_width/2),int(vid_height)))
        
        
        
        
        
        
        self.cdu_screen_label_R = QtWidgets.QLabel(self.centralwidget)
        self.cdu_screen_label_R.setGeometry(QtCore.QRect(int(vid_width/2-50), 60,
                                                       60,
                                                       50))
        self.cdu_screen_label_R.setObjectName("graphicsView")
        self.cdu_screen_label_R.setPixmap(QPixmap(''))
        
        self.cdu_screen_label_R.setScaledContents(True)
        
        
        
        self.webEngineView = QtWebEngineWidgets.QWebEngineView(self.centralwidget)
        self.webEngineView.load(QtCore.QUrl().fromLocalFile('/home/bisagn/Music/ARMY/LORROS/templates/map.html'))
        self.webEngineView.setGeometry(3, int(vid_height/20+87),int(vid_width/2.8),int(vid_height/2.3*2-5))
        
        self.clear_targets_button = QtWidgets.QPushButton(self.centralwidget)
        self.clear_targets_button.setGeometry(QtCore.QRect(350, 20, 141, 25))
        self.clear_targets_button.setObjectName("pushButton_3")
        self.show_on_map_button = QtWidgets.QPushButton(self.centralwidget)
        self.show_on_map_button.setGeometry(QtCore.QRect(490, 20, 141, 25))
        self.show_on_map_button.setObjectName("pushButton_4")

        self.label1 = QtWidgets.QLabel(self.centralwidget)

        # vid_width = self.window_width - 20
        # vid_height = self.window_height - 80
        self.label1.setGeometry(QtCore.QRect(int(vid_width/2+10), 60, int(vid_width/2), int(vid_height+6)))
        self.label1.setStyleSheet("border: 1px solid black;")
        self.label1.setObjectName("graphicsView")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)



        self.recording_s = QtWidgets.QPushButton(self.statusbar)
        self.recording_s.setGeometry(QtCore.QRect(int(vid_width/4*3-141), 00, 141, 25))
        self.recording_s.setObjectName("pushButton_4")

        # self.recording_sp = QtWidgets.QPushButton(self.statusbar)
        # self.recording_sp.setGeometry(QtCore.QRect(vid_width/4*3, 00, 141, 25))
        # self.recording_sp.setObjectName("pushButton_4")


        self.screen_rec = QtWidgets.QPushButton(self.statusbar)
        self.screen_rec.setGeometry(QtCore.QRect(300,00,150,25))
        self.screen_rec.setObjectName("screen record")




        #**********************#
        
        # self.centralwidget = QtWidgets.QWidget(MainWindow)
        # self.centralwidget.setObjectName("centralwidget")
        
        
        self.swap_to_spr = QtWidgets.QPushButton(self.centralwidget)
        self.swap_to_spr.setGeometry(QtCore.QRect(int(vid_width/4*3-90), 20, 180, 25))
        self.swap_to_spr.setObjectName("Swap To Sprectogram")
        
        
        pyqtgraph.setConfigOption('background', 'w') 
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.label1)
        self.horizontalLayout.setObjectName("horizontalLayout")
        # self.pbLevel = QtWidgets.QProgressBar(self.label1)
        # self.pbLevel.setMaximum(1000)
        # self.pbLevel.setProperty("value", 123)
        # self.pbLevel.setTextVisible(False)
        # self.pbLevel.setOrientation(QtCore.Qt.Vertical)
        # self.pbLevel.setObjectName("pbLevel")
        # self.horizontalLayout.addWidget(self.pbLevel)
        self.frame = QtWidgets.QFrame(self.label1)
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame.setObjectName("frame")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 50)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setObjectName("label_3")
        self.label_3.setGeometry(0,0, int(vid_width/2),22)
        
        # self.verticalLayout.addWidget(self.label_3)
        self.grPCMnew = PlotWidget(self.frame)
        self.grPCMnew.setObjectName("grPCMnew")
        # self.verticalLayout.addWidget(self.grPCMnew)
        self.grPCMnew.setGeometry(0,24, int(vid_width/4), 274)
        
        
        
        
        self.recording_sp = QtWidgets.QLabel(self.frame)
        self.recording_sp.setObjectName("label_")
        self.recording_sp.setGeometry(int(vid_width/4-60),26,60,50)
        
        self.recording_sp.setPixmap(QPixmap(''))
        self.recording_sp.setScaledContents(True)
        self.recording_sp.setStyleSheet("border :none;")
        
        self.label_h = QtWidgets.QLabel(self.frame)
        self.label_h.setObjectName("label_3")
        self.label_h.setGeometry(int(vid_width/4-1),-2, int(vid_width/4),274)
        
        
        self.label_hh = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h1)
        self.label_hh.setText('History')
        self.label_hh.setGeometry(0,0,int(vid_width/4),26)

        self.tableWidget = QtWidgets.QTableWidget(self.label_h)

        self.tableWidget.setGeometry(QtCore.QRect(0, 27,int(vid_width/2-20), int(vid_height/3+50)))
        self.tableWidget.setRowCount(10)
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnWidth(0,180)
        self.tableWidget.setColumnWidth(1,130)
        self.tableWidget.setColumnWidth(2,130)
        self.tableWidget.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.tableWidget.setHorizontalHeaderLabels(['Prediction','Date','Time'])

        self.loaddata()
        
        # font_H = QtGui.QFont()
        
        # font_H.setPointSize(10)
        
        # self.label_h1 = QtWidgets.QLabel(self.label_h)
        # self.label_h1.setFont(font_H)
        # # self.verticalLayout.addWidget(self.label_h1)
        # self.label_h1.setGeometry(0,25, vid_width/4,51)
        # self.label_h1.setFont(font_H)
        
        # self.label_h2 = QtWidgets.QLabel(self.label_h)
        # self.label_h2.setFont(font_H)
        # # self.verticalLayout.addWidget(self.label_h2)    
        # self.label_h2.setGeometry(0,75, vid_width/4,51)

        
        # self.label_h3 = QtWidgets.QLabel(self.label_h)
        # self.label_h3.setFont(font_H)
        # # self.verticalLayout.addWidget(self.label_h3)    
        # self.label_h3.setGeometry(0,125, vid_width/4,51)

        
        # self.label_h4 = QtWidgets.QLabel(self.label_h)
        # self.label_h4.setFont(font_H)
        # # self.verticalLayout.addWidget(self.label_h4)   
        # self.label_h4.setGeometry(0,175, vid_width/4,51)

        
        # self.label_h5 = QtWidgets.QLabel(self.label_h)
        # self.label_h5.setFont(font_H)
        # # self.verticalLayout.addWidget(self.label_h5)      
        # self.label_h5.setGeometry(0,225, vid_width/4,51)

        
        
        
        font = QtGui.QFont()
        self.prediction = QtWidgets.QLabel(self.frame)
        self.prediction.setGeometry(0,300,int(vid_width/2), 50)
        
        font.setPointSize(20)
        self.prediction.setFont(font)
        self.prediction.setObjectName("prediction")
        self.prediction.setStyleSheet("padding-left:30px")
        
        
        
        # self.verticalLayout.addWidget(self.prediction,0, QtCore.Qt.AlignHCenter)
        
        
        # self.label_rh = QtWidgets.QLabel(self.frame)
        # self.label_rh.setObjectName("label")
        # self.label_rh.setGeometry(0,352,880, 24)
        
        #class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        
        self.label_rhlv = QtWidgets.QLabel(self.frame)
        self.label_rhlv.setText("LIGHT VEHICLE")
        self.label_rhlv.setGeometry(0,352,int(vid_width/6), 24)
        self.label_rhlv.setStyleSheet("padding-left :70px")
        self.label_rhhv= QtWidgets.QLabel(self.frame)
        self.label_rhhv.setText("HEAVY VEHICLE")
        self.label_rhhv.setGeometry(int(vid_width/6-1),352,int(vid_width/6), 24)
        self.label_rhhv.setStyleSheet("padding-left :70px")
        self.label_rhgm = QtWidgets.QLabel(self.frame)
        self.label_rhgm.setText("GROUP OF MEN")
        self.label_rhgm.setGeometry(int(vid_width/6*2-3),352,int(vid_width/6),24)
        self.label_rhgm.setStyleSheet("padding-left :70px")
        
        
        
        # self.label_r = QtWidgets.QLabel(self.frame)
        # self.label_r.setObjectName("label")
        # self.label_r.setGeometry(0,378,vid_width/2, 177)
        
        
        self.label_rhlv = QtWidgets.QLabel(self.frame)
        self.label_rhlv.setGeometry(0,378,int(vid_width/6), 177)
        self.label_rhlv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/my_plot.png'))
        self.label_rhlv.setScaledContents(True)
        self.label_rhhv= QtWidgets.QLabel(self.frame)
        self.label_rhhv.setGeometry(int(vid_width/6-1),378,int(vid_width/6), 177)
        self.label_rhhv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/heavy_vehicle.png'))
        self.label_rhhv.setScaledContents(True)
        self.label_rhgm = QtWidgets.QLabel(self.frame)
        self.label_rhgm.setGeometry(int(vid_width/6*2-3),378,int(vid_width/6-16), 177)
        self.label_rhgm.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/Gom.png'))
        self.label_rhgm.setScaledContents(True)
        
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setObjectName("label")
        self.label.setGeometry(0,557,int(vid_width/2), 24)
        
        # src = cv2.imread('name.png')
        # image = cv2.rotate(src, cv2.ROTATE_90_COUNTERCLOCKWISE)
        # cv2.imwrite('newsp.png',image)
        # self.label_2.setPixmap(QPixmap('newsp.png'))

        # self.verticalLayout.addWidget(self.frame)
        self.grFFT = PlotWidget(self.frame)
        self.grFFT.setObjectName("grFFT")
        self.grFFT.setGeometry(0,583,int(vid_width/2-20), 300)
        # self.grFFT.showGrid(x=True, y=True, alpha = 0.3)
        self.grFFT.setLabel('left', 'Frequency', units='KHz')
        # self.grFFT.setLabel('bottom', 'Time')
        # self.grFFT.addLegend()
        # self.verticalLayout.addWidget(self.grFFT)
        
        
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.label_2.setGeometry(72,598,int(vid_width/2-120), 251)
        self.label_2.setStyleSheet("border :none;")
        # self.label_2.setScaledContents(True)
        





        
        
        # self.verticalLayout.addWidget(self.label_2)
        
        
        # self.grPCM = PlotWidget(self.frame)
        # self.grPCM.setObjectName("grPCM")
        # self.grPCMa.setGeometry(0,378,880, 500)
        # self.verticalLayout.addWidget(self.grPCMa)
        self.horizontalLayout.addWidget(self.frame)
        MainWindow.setCentralWidget(self.centralwidget)
        
        pyqtgraph.setConfigOption('background', 'w')
        
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        
        # self.grFFT.plotItem.showGrid(True, True, 0.5)
        # self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.grPCMnew.plotItem.showGrid(True, True, 1)
        self.maxFFT = 1
        self.maxPCM = 0
        prediction_print = ''
        self.sc = StreamController()
        self.sc.setup_stream()

        #**********************#
        

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.target_capture_button.clicked.connect(self.target_capture_button_listener)
        self.clear_targets_button.clicked.connect(self.clear_targets_button_listener)
        self.show_on_map_button.clicked.connect(self.map_show)

        self.recording_s.clicked.connect(self.recording_start)
        # self.recording_sp.clicked.connect(self.recording_stop)
        self.screen_rec.clicked.connect(self.screen_record)
        
        self.swap_to_spr.clicked.connect(self.swap_to_sprectogram)

        
        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        self.video_display_th = Thread(880, 920)
        self.video_display_th.changePixmap.connect(self.set_image)
        self.video_display_th.setTerminationEnabled(True)
        self.video_display_th.start()
        
        # self.ear = SWHear.SWHear.stream_readchunk(self)
        # self.ear.stream_start()
        
    def screen_record(self):
        global screen_record_onoff
        if screen_record_onoff == False:
            screen_record_onoff = True
            cdu_screen_border = 'on'

            massage = 'Audio recording Started...'
            self.show_info_messagebox(massage)

            date_time = dt.now()
            # print(date_time)
            global current_frame
            os.mkdir(f'/home/bisagn/Music/ARMY/BFSR_SR/Recording/Screen_record/{str(date_time)}/')
            # vid_cap = cv2.VideoCapture()
            count =0
            
            cv2.namedWindow("IMAGE", cv2.WINDOW_NORMAL)
            cv2.resizeWindow("IMAGE", 50, 50)
            self.cdu_screen_label_R.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/screenrecorder.png'))
            
            while screen_record_onoff:
                # if cdu_screen_border == 'on':
                #     self.cdu_screen_label_R.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/screenrecorder.png'))

                #     cdu_screen_border = 'off'
                # else:
                #     self.cdu_screen_label_R.setPixmap(QPixmap(''))

                #     cdu_screen_border = 'on'


                
                cv2.imwrite(f'/home/bisagn/Music/ARMY/BFSR_SR/Recording/Screen_record/{str(date_time)}/img_{count}.png',current_frame) 
                # cv2.imshow('IMAGE',current_frame)
                count+=1
                # time.sleep(2)
                
                cv2.waitKey(1) 
        else:
            screen_record_onoff = False
            self.cdu_screen_label_R.setPixmap(QPixmap(''))
            

            massage = 'Screen recording Stoped...'
            self.show_info_messagebox(massage)

        
    def swap_to_sprectogram(self):
        global swap_wav
        if swap_wav == 'Waveform':
            self.label_rhlv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/LV.png'))
            self.label_rhhv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/HV.png'))
            self.label_rhgm.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/GOMS.png'))
            self.swap_to_spr.setText("Swap To Waveform")
            swap_wav = 'Sprectogram'
        else:
            self.label_rhlv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/my_plot.png'))
            self.label_rhhv.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/heavy_vehicle.png'))
            self.label_rhgm.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/Gom.png'))
            self.swap_to_spr.setText("Swap To Sprectogram")
            swap_wav = 'Waveform'
            
            

        
    def update_streamplot(self):
        self.pdataitem.setData(self.sc.data)
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Cap BFSR Loc"))
        self.target_capture_button.setText(_translate("MainWindow", "Cap Tgt Loc"))
        self.clear_targets_button.setText(_translate("MainWindow", "Clear Tgts"))
        self.show_on_map_button.setText(_translate("MainWindow", "Show Map"))
        self.label.setText(_translate("MainWindow", "Spectrogram : "))
        self.label_3.setText(_translate("MainWindow", "Waveform Wav : "))
        self.prediction.setText(_translate("MainWindow", "<>"))
        self.swap_to_spr.setText(_translate("MainWindow", "Swap To Sprectogram"))

        self.recording_s.setText(_translate("MainWindow", "Audio Record"))
        # self.recording_sp.setText(_translate("MainWindow", "Rec. Stop"))

        self.screen_rec.setText(_translate("MainWindow", "Screen Record"))

        
        
        # self.label_2.setText(_translate("MainWindow", "Raw Data (PCM):"))
        
        
        
    def show_info_messagebox(self,massage):
        
        self.msg = QMessageBox()
        self.msg.setIcon(QMessageBox.Information)

        # setting message for Message Box
        self.msg.setText(massage)
        
        # setting Message box window title
        self.msg.setWindowTitle("Information")
        
        # # declaring buttons on Message Box
        # self.msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        
        time_milliseconds = 3000

        QtCore.QTimer.singleShot(time_milliseconds, lambda : self.msg.done(0))
        # start the app
        self.msg.exec_() 

    def updateee(self, chunk):
        # normalized, windowed frequencies in data chunk
        spec = np.fft.rfft(chunk*self.win) / CHUNKSZ
        # get magnitude 
        psd = abs(spec)
        # convert to dB scale
        psd = 20 * np.log10(psd)

        # roll down one and replace leading edge with new data
        self.img_array = np.roll(self.img_array, -1, 0)
        self.img_array[-1:] = psd
        try:
            matplotlib.image.imsave('/home/bisagn/Music/ARMY/BFSR_SR/Images/name.png', self.img_array)
            
            
            src = cv2.imread('/home/bisagn/Music/ARMY/BFSR_SR/Images/name.png')
            image = cv2.rotate(src, cv2.ROTATE_90_COUNTERCLOCKWISE)
            cv2.imwrite('/home/bisagn/Music/ARMY/BFSR_SR/Images/newsp.png',image)
            
            self.label_2.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/newsp.png'))
            self.label_2.setScaledContents(True)
        except:
            pass
    def update(self):
        # from BFSR_Simple_GUI_v2 import MicThread
        # if not earac.data is None and not earac.fft is None:
                # self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            # if np.max(earac.fft) > self.maxFFT:
        # self.maxFFT = np.max(np.abs(self.fft))
        # self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
        # self.grFFT.plotItem.setRange(yRange=[0, 1])
                
        # pcmMax = np.max(np.abs(self.sc.data))
        # if pcmMax > self.maxPCM:
        #     self.maxPCM = pcmMax
        # try:
        #     self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
        #     pass
        # except TypeError:
        #     self.pbLevel.setValue(0)
        # print('===============>>>>>>>>>>'+str(prediction_history))
        
        
        
        # self.label_h1.setText(prediction_history[4])
        # self.label_h2.setText(prediction_history[3])
        # self.label_h3.setText(prediction_history[2])
        # self.label_h4.setText(prediction_history[1])
        # self.label_h5.setText(prediction_history[0])
        
                

        # HVLISTf = [match for match in prediction_history if "HEAVY VEHICLE" in match]
        # LVLISTf = [match for match in prediction_history if "LIGHT VEHICLE" in match]
        
        # # {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1}'No sound or Noise'
        # if len(HVLISTf) > 2:
        #     self.prediction.setText(HVLISTf[0])
        # elif len(LVLISTf) > 2:
        #     self.prediction.setText(LVLISTf[0])
        # else:
        #     self.prediction.setText(prediction_print)
            
            
        self.prediction.setText(prediction_print)
        
        
        # pcmMax = np.max(np.abs(self.sc.data))
        # if pcmMax > self.maxPCM:
        #     self.maxPCM = pcmMax
        #     self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
        # if np.max(fft) > self.maxFFT:
        #     self.maxFFT = np.max(np.abs(fft))
        #     self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
            # self.grFFT.plotItem.setRange(yRange=[0, 1])
        # pen = pyqtgraph.mkPen(color='b')
        # self.grPCMa.plot(self.win, pen=pen, clear=True)
        # pen = pyqtgraph.mkPen(color='r')
        self.grFFT.plotItem.setRange(xRange=[0, 7])
        self.grFFT.plotItem.setRange(yRange=[0, 22])
        
        
        # self.grFFT.plot(fftx, fft/self.maxFFT, pen=pen, clear=True)
        pen = pyqtgraph.mkPen(color='b')         
        self.grPCMnew.plotItem.setRange(yRange=[-30000, 30000])
        # self.grPCMnew.plotItem.setRange(xRange=[0, 300000])
        self.grPCMnew.plot(self.sc.data, pen=pen, clear=True)
        # global var
        # var = self.ear.final_prediction[0:14]
        # with open('file_audio.txt','w') as f:
        #     f.write(str(var))
                
      
               
        self.loaddata()

        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY

    def loaddata(self):
        conn = sqlite3.connect('/home/bisagn/Music/ARMY/BFSR_SR/BFSR_SR.db')
        cursor = conn.cursor()
        global prediction_history_save,date_pred,time_pred
        cursor=conn.cursor()
        s = 'select id,PRED,DATE,TIME from MR order by id desc'
        cursor.execute(s)
        count=[]
        data = cursor.fetchall()
        for index,i in enumerate(data):
                # print(index+1,'=-=-=-=count-=-=-=-')
                count.append(index)
        c = count[-1]
        self.tableWidget.setRowCount(c)
        tableindex=0
        try: 
            for row in cursor.execute(s):
                self.tableWidget.setItem(tableindex,0,QtWidgets.QTableWidgetItem(str(row[1])))
                self.tableWidget.setItem(tableindex,1,QtWidgets.QTableWidgetItem(str(row[2])))
                self.tableWidget.setItem(tableindex,2,QtWidgets.QTableWidgetItem(str(row[3])))
    
                tableindex+=1

        except:
            pass
        
    def capture_bfsr_location_button_listener(self):
        print("capture_bfsr_location_button function called")
        global current_frame
        try:
            cv2.imwrite('/home/bisagn/Music/ARMY/BFSR_SR/logs/bfsr_location.png',current_frame)
            # For image of size 640x480
            roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            ret = get_bfsr_location(roi,self._easyocr, self.transformer)
            # print(ret)
            dialog = SR_OWN_LOC(str(ret['easting']),str(ret['northing']),(ret['date']),(ret['time']))
            dialog.exec_()
        except:
            dialog = SR_OWN_LOC('','','','')
            dialog.exec_()

    def target_capture_button_listener(self):
        print("target_capture_button function called")
        # cv2.imwrite('logs/target_location.png',current_frame)
        try:  
            date=dt.now().strftime('%d-%m-%Y')
            time=dt.now().strftime('%H:%M:%S')
        
            roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            ret = get_target_location(roi,self.target_type, self._easyocr, self.transformer) 
        # {'easting': '2534269', 'thing': '1023288', 'range': '87', 'az': '342.6', 'speed': '0.13', 'heading': '146.3', 'northing': '1023288', 'type': 'Target Location', 'subtype': '', 'date': '07/03/2023', 'time': '17:38:25'}
        

            dialog = Dialog(str(ret['easting']),str(ret['northing']),date,time,str(ret['az']),str(ret['range']),str(ret['speed']),str(prediction_ocr),str(ret['heading']))
            dialog.exec_()
        except:
            dialog = Dialog('','',date,time,'','','',str(prediction_ocr),'')
            dialog.exec_()

    def map_show(self):

        webbrowser.open('file:///home/bisagn/Music/ARMY/BFSR_SR/templates/map.html')

    def clear_targets_button_listener(self):
        print("clear_targets_button function called")
        # clear_target_locations()

        os.remove('/home/bisagn/Music/ARMY/BFSR_SR/templates/Target_location.geojson')


        Cap_tgt.clear_list_of_target(self)
    
    def recording_start(self):
        global recording,audio_record_onoff,rec_list
    
        # lbl_on_off= 'on'
        if audio_record_onoff:
            recording = 'Start'
            
            massage = 'Audio recording Started...'
            self.show_info_messagebox(massage)
            self.recording_sp.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/recorder.png'))
            
            # while recording == 'Start':
            #     time.sleep(1)
            #     if lbl_on_off == 'on':
            #         self.recording_sp.setPixmap(QPixmap('/home/bisagn/Music/ARMY/BFSR_SR/Images/recorder.png'))
            #         lbl_on_off = 'off'
                    
            #     else:                    
            #         lbl_on_off = 'on'
            #         self.recording_sp.setPixmap(QPixmap(''))
            
            audio_record_onoff = False
            
        else:
            recording = 'Stop'
            self.recording_sp.setPixmap(QPixmap(''))
            
            
            massage = 'Audio recording Stoped...'
            self.show_info_messagebox(massage)
        
            date_time = dt.now()
            p =pyaudio.PyAudio()
            channels = 2
            fs = 44100  # Record at 44100 samples per second
            # Save the recorded data as a WAV file
            wf = wave.open(f'/home/bisagn/Music/ARMY/BFSR_SR/Recording/Audio_recording/{date_time}.WAV', 'wb')
            wf.setnchannels(channels)
            wf.setsampwidth(p.get_sample_size(pyaudio.paInt16))
            wf.setframerate(fs)
            wf.writeframes(b''.join(rec_list))
            wf.close()
            rec_list.clear()
            audio_record_onoff = True
            


    @pyqtSlot(QImage)
    def set_image(self, image):
        # pass
        # PhotoViewer.setPhoto(QtGui.QPixmap(image))
        # 'Load image' button
        # self.viewer._zooom(self)
        self.viewer.setPhoto(QtGui.QPixmap(image))
        # self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))
        
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_1:
            self.target_type = "No sound"
        elif event.key() == QtCore.Qt.Key_2:
            self.target_type = "Heavy vehicle"
        elif event.key() == QtCore.Qt.Key_3:
            self.target_type = "Light vehicle"
        elif event.key() == QtCore.Qt.Key_4:
            self.target_type = "Group of men"
        print(self.target_type)
        
# cursor = conn.cursor()
# command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
# cursor.execute(command)
# comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
# cursor.execute(comm)
# cursor.close()
# conn.commit()
from pyqtgraph import PlotWidget


if __name__ == "__main__":
    
    # sys.stdout = open('stdout.txt', 'w')
    # sys.stderr = open('stderr.txt', 'w')

    os.environ["CUDA_VISIBLE_DEVICES"] = "1"

    kill_set_img_th = False
    current_frame = True

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    
    ui.update()
    # app = QtGui.QApplication([])
    # w = SpectrogramWidget()
    ui.read_collected.connect(ui.updateee)

    mic = MicrophoneRecorder(ui.read_collected)

    # time (seconds) between reads
    interval = FS/CHUNKSZ
    print(interval,'=----------------------')
    t = QtCore.QTimer()
    t.timeout.connect(mic.read)
    t.start(int(1000/interval))
    MainWindow.show()
    
    
    
    
    exit_status = app.exec_()
    kill_set_img_th = True
    sys.exit(exit_status)
