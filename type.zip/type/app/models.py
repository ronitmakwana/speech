from django.db import models

# Create your models here.


class Job(models.Model):
    name = models.CharField(max_length=30,default=None)
    # date = models.DateField()
    # time_started = models.DateTimeField(blank=True, null=True)
    # time_finished = models.DateTimeField(blank=True, null=True)

    # @property
    # def duration(self):
    #     if self.time_finished is not None and self.time_started is not None:
    #         return self.time_finished - self.time_started

    # def __str__(self):
    #     return self.name