from django.urls import path
from .views import index,starts,stop

urlpatterns = [
    path('index/',index,name='index'),
    path('starts',starts,name='starts'),
    path('stop',stop,name='stops')
]
