import torch
from model import AudioCNNClassifier
from dataset_utils import get_datasets
from torch.utils.data import DataLoader
import pandas as pd
import warnings


warnings.filterwarnings('ignore')

''' to detect what causes nan loss
 only for debugging purposes
 slows down training
'''
# torch.autograd.set_detect_anomaly(True)

desired_sr = 16000
max_audio_duration_ms = 5000
batch_size = 8
device = 'cuda:1' if torch.cuda.is_available() else 'cpu'

_, _, test_dataset = get_datasets(meta_path="/home/user/Documents/bfsr/phase_2/annotations.csv",
                                    data_dir_path="/home/user/Documents/bfsr/phase_2",
                                    desired_sr=desired_sr,
                                    max_audio_duration_ms=max_audio_duration_ms)

test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=True, pin_memory=False, num_workers=32)

checkpoint = torch.load("models/bfsr_cnn_librosa_chiloda_v3.pt", map_location=device)
print(f"Epoch: {checkpoint['epoch']}")
print(f"Val. loss after training: {checkpoint['val_loss']}")

cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])
cnn = cnn.to(device)

cnn.eval()
nb_correct = 0


# data = []
# with torch.no_grad():
#     for i in range(len(test_dataset)):
#         fp = test_dataset.file_paths[i]
#         X, y = test_dataset[i]
#         X = X.unsqueeze(0)

#         X = X.to(device)
#         outs = cnn(X)

#         _, preds = torch.max(outs, 1)
#         nb_correct += (preds.cpu().item() == y)

#         probs = torch.nn.functional.softmax(outs, dim=1).cpu()


#         data.append([fp, y, probs[0][0].item(), 
#                 probs[0][1].item(), probs[0][2].item()])

# print(nb_correct/len(test_dataset), checkpoint['idx_to_class'])


# df = pd.DataFrame(data)
# df.to_csv("test_preds.csv", index=False)

with torch.no_grad():
    for data, labels in test_loader:
        data = data.to(device)
        labels = labels.to(device)

        outs = cnn(data)
        _, preds = torch.max(outs, 1)

        nb_correct += (preds == labels).sum().item()

print(f"Test Acc: {nb_correct / len(test_dataset)}")
