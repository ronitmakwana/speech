from PyQt5 import QtGui, QtCore
import sys
import ui_main
import numpy as np
import pyqtgraph
import SWHear
import warnings
import pyaudio
import wave
import random
import sys
import sqlite3
import json
import faulthandler

faulthandler.enable()

warnings.filterwarnings("ignore")
conn = sqlite3.connect('BFSR_PRED1.db')
dict={'target':''}
class ExampleApp(QtGui.QMainWindow, ui_main.Ui_MainWindow):
    def __init__(self, parent=None):
        pyqtgraph.setConfigOption('background', 'w')  # before loading widget
        super(ExampleApp, self).__init__(parent)
        self.setupUi(self)
        self.grFFT.plotItem.showGrid(True, True, 0.7)
        self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.maxFFT = 0
        self.maxPCM = 0
        self.ear = SWHear.SWHear(device=7, rate=44100, updatesPerSecond=20)
        self.ear.stream_start()

    def update(self):
        if not self.ear.data is None and not self.ear.fft is None:
            pcmMax = np.max(np.abs(self.ear.data))
            if pcmMax > self.maxPCM:
                self.maxPCM = pcmMax
                self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            if np.max(self.ear.fft) > self.maxFFT:
                self.maxFFT = np.max(np.abs(self.ear.fft))
                # self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
                self.grFFT.plotItem.setRange(yRange=[0, 1])
            try:
                self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
            except TypeError:
                self.pbLevel.setValue(0)
            self.prediction.setText(self.ear.final_prediction)
            pen = pyqtgraph.mkPen(color='b')
            self.grPCM.plot(self.ear.datax, self.ear.data, pen=pen, clear=True)
            pen = pyqtgraph.mkPen(color='r')
            self.grFFT.plot(self.ear.fftx, self.ear.fft / self.maxFFT, pen=pen, clear=True)
            var = self.ear.final_prediction[0:14]
            with open('file.txt','w') as f:
                f.write(str(var))
               
                cursor = conn.cursor()
                command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
                cursor.execute(command)
                comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
                cursor.execute(comm)
                conn.commit()
                # command = "select target_name from pred order by id desc"
                # cursor.execute(command)
                # result = cursor.fetchone()
                # print(result)
                # dict['target']=result[0]
                # print(dict)
                # json_data = json.dumps(dict)
                # print(json_data)
                            
        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY repeat



if __name__ == "__main__":

    sys.stdout = open('stdout.txt', 'w')
    sys.stderr = open('stderr.txt', 'w')
    app = QtGui.QApplication(sys.argv)
    form = ExampleApp()
    form.show()
    form.update()  # start with something
    app.exec_()
    print("DONE")
#     '''
#     wf = wave.open("data.wav", 'wb')
#     wf.setnchannels(1)
#     wf.setsampwidth(form.ear.p.get_sample_size(pyaudio.paInt16))
#     wf.setframerate(44100)
#     wf.writeframes(b''.join(form.ear.frames))
#     wf.close()
#     '''
#     form.ear.keepRecording = False
#     # cleanup_stop_thread()

#     sys.stdout.close()
#     sys.stderr.close()


# cursor = conn.cursor()
# command = "select target_name from pred order by id desc"
# # command = "TRUNCATE TABLE pred"

# cursor.execute(command)
# # conn.commit()
# result = cursor.fetchall()
# print(result)
# dict['target']=result[0]
# print(dict)
# json_data = json.dumps(dict)
# print(json_data)
