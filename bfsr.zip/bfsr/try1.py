# import easyocr
# import cv2
# from PIL import Image, ImageEnhance


# im = Image.open(r"logs/target_location.png")
# # left,top,right,bottom = 537,235,622,309  # all
# # left,top,right,bottom = 536,275,622,289  # range
# left,top,right,bottom = 535,235,618,346 #all final

# im1 = im.crop((left, top, right, bottom))
# # im1.show()
# im1.save('00.bmp')


# # get image
# filepath = "00.bmp"
# img = Image.open(filepath)
  
# # get width and height
# width = img.width
# height = img.height


# image = Image.open('00.bmp')
# print(f"Original size : {image.size}") # 5464x3640

# sunset_resized = image.resize((width*5, height*5))
# sunset_resized.save('00.bmp')

# im = Image.open('00.bmp')
# enhancer = ImageEnhance.Contrast(im)


# factor = 1.0 #increase contrast
# im_output = enhancer.enhance(factor)
# im_output.save('00.bmp')

# im = Image.open('00.bmp')
# enhancer = ImageEnhance.Brightness(im)


# factor = 1.0 #increase contrast
# im_output = enhancer.enhance(factor)
# im_output.save('00.bmp')


# Keyword = {'easting': 1,'north': 1,'range': 1,'az': 1,'speed': 1,'heading': 1}

# im_output.show()

# reader = easyocr.Reader(['en'])  
# results = reader.readtext('00.bmp', paragraph=True)
# # print(results) 
# list_data = []
# for i in results:
#     Data_EN = i[1].replace(' ','').replace('\x0c','')
#     Data_EN = i[1].split("\n")
#     list_data.append(Data_EN)
# # print(list_data)

# east = list_data[0][0]
# while len(east) < 7:
#     east = east + '0'
# Keyword['easting'] = int(east)
# north = list_data[1][0]
# while len(north) < 7:
#     north = north + '0'
# Keyword['north'] = int(north)
# Keyword['range'] = float(list_data[2][0])
# Keyword['az'] = float(list_data[3][0])
# Keyword['speed'] = float(list_data[4][0])
# Keyword['heading'] = float(list_data[5][0])
# # print('No Data Found') 
# print('Keyword',Keyword)

import easyocr
import cv2
from PIL import Image, ImageEnhance


im = Image.open(r"bfsr_location.png")
# left,top,right,bottom = 537,235,622,309  # all
# left,top,right,bottom = 536,275,622,289  # range
left,top,right,bottom = 330,287,410,400 #all final

im1 = im.crop((left, top, right, bottom))
# im1.show()
im1.save('00.bmp')


# get image
filepath = "00.bmp"
img = Image.open(filepath)
  
# get width and height
width = img.width
height = img.height


image = Image.open('00.bmp')
print(f"Original size : {image.size}") # 5464x3640

sunset_resized = image.resize((width*5, height*5))
sunset_resized.save('00.bmp')

im = Image.open('00.bmp')
enhancer = ImageEnhance.Contrast(im)


factor = 1.0 #increase contrast
im_output = enhancer.enhance(factor)
im_output.save('00.bmp')

im = Image.open('00.bmp')
enhancer = ImageEnhance.Brightness(im)


factor = 1.0 #increase contrast
im_output = enhancer.enhance(factor)
im_output.save('00.bmp')


Keyword = {'easting': 1,'north': 1,'lat': 1,'long': 1}

im_output.show()

reader = easyocr.Reader(['en'])  
results = reader.readtext('00.bmp', paragraph=True)
# print(results) 
list_data = []
for i in results:
    Data_EN = i[1].replace(' ','').replace('\x0c','')
    Data_EN = i[1].split("\n")
    list_data.append(Data_EN)
print(list_data)

east = list_data[0][0]
while len(east) < 7:
    east = east + '0'
Keyword['easting'] = int(east)
north = list_data[1][0]
while len(north) < 7:
    north = north + '0'
Keyword['north'] = int(north)
lat = list_data[2][0]
lat = lat.replace(' ', '')
Keyword['lat'] = float(lat)
long = list_data[3][0]
long = lat.replace(' ', '')
Keyword['long'] = float(long)
print('Keyword',Keyword)