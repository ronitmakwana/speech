# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
import os
import sys
import threading
import time
import cv2
import easyocr
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer
from helpers import get_bfsr_location, get_target_location, clear_target_locations
import numpy as np


class Thread(QThread):
    changePixmap = pyqtSignal(QImage)

    def __init__(self, width, height):
        super().__init__()
        self.width, self.height = width, height

    def run(self):
        # self._stop_event = threading.Event()
        global kill_set_img_th
        cap = cv2.VideoCapture(0) # 'cdu_screen_video.mp4')
        while not kill_set_img_th:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = np.copy(frame)
                current_frame = cv2.resize(current_frame, (640, 480))
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = img.shape
                bytes_per_line = ch * w
                qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
                p = qt_img.scaled(self.width, self.height, QtCore.Qt.IgnoreAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)
            else:
                break
        cap.release()

    # def stop(self):
    #     self._stop_event.set()

'''
def capture_target_location(_easyocr, transformer):
    # For image of size 640x480
    global kill_ocr_thread
    roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
    while not kill_ocr_thread:
        if ocr_on_target_screen_flag:
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            get_target_location(roi, _easyocr, transformer)
            # time.sleep(15)

'''

class Ui_MainWindow(QWidget):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")

        screen_size = app.primaryScreen().size()
        self.window_width = screen_size.width() - 100
        self.window_height = screen_size.height() - 100

        MainWindow.setFixedSize(self.window_width, self.window_height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(10, 20, 201, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.target_capture_button = QtWidgets.QPushButton(self.centralwidget)
        self.target_capture_button.setGeometry(QtCore.QRect(210, 20, 141, 25))
        self.target_capture_button.setObjectName("pushButton_2")
        self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)

        vid_width = self.window_width - 20
        vid_height = self.window_height - 80
        self.cdu_screen_label.setGeometry(QtCore.QRect(10, 60,
                                                       vid_width,
                                                       vid_height))
        self.cdu_screen_label.setObjectName("graphicsView")
        self.clear_targets_button = QtWidgets.QPushButton(self.centralwidget)
        self.clear_targets_button.setGeometry(QtCore.QRect(350, 20, 141, 25))
        self.clear_targets_button.setObjectName("pushButton_3")
        self.show_on_map_button = QtWidgets.QPushButton(self.centralwidget)
        self.show_on_map_button.setGeometry(QtCore.QRect(490, 20, 141, 25))
        self.show_on_map_button.setObjectName("pushButton_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.target_capture_button.clicked.connect(self.target_capture_button_listener)
        self.clear_targets_button.clicked.connect(self.clear_targets_button_listener)

        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        self.video_display_th = Thread(vid_width, vid_height)
        self.video_display_th.changePixmap.connect(self.set_image)
        self.video_display_th.setTerminationEnabled(True)
        self.video_display_th.start()


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Cap BFSR Loc"))
        self.target_capture_button.setText(_translate("MainWindow", "Cap Tgt Loc"))
        self.clear_targets_button.setText(_translate("MainWindow", "Clear Tgts"))
        self.show_on_map_button.setText(_translate("MainWindow", "Show Map"))


    def capture_bfsr_location_button_listener(self):
        print("capture_bfsr_location_button function called")
        global current_frame

        # For image of size 640x480
        roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_bfsr_location(roi, self._easyocr, self.transformer)
        

    def target_capture_button_listener(self):
        print("target_capture_button function called")
        roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_target_location(roi, self._easyocr, self.transformer) 

    def clear_targets_button_listener(self):
        print("clear_targets_button function called")
        clear_target_locations()
        

    @pyqtSlot(QImage)
    def set_image(self, image):
        self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))


if __name__ == "__main__":

    # sys.stdout = open('stdout.txt', 'w')
    # sys.stderr = open('stderr.txt', 'w')

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    kill_set_img_th = False
    current_frame = True

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    exit_status = app.exec_()
    kill_set_img_th = True
    # ui.video_display_th.stop()

    # sys.stdout.close()
    # sys.stderr.close()
    sys.exit(exit_status)
