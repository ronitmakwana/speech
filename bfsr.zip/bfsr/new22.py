
from setuptools import setup

setup(
    name='My First Setup File',
    version='1.0',
    scripts=['new2.py'],
)