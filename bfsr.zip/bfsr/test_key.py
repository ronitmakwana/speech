import sys
from PyQt5.QtWidgets import (QApplication, QWidget)
from PyQt5.Qt import Qt
from PyQt5 import QtCore, QtWidgets
class MainWindow(QWidget):
	def __init__(self):
		super().__init__()
		
	def keyPressEvent(self, event):
		if event.key() == QtCore.Qt.Key_1:
			self.target_type = "No sound"
		elif event.key() == QtCore.Qt.Key_2:
			self.target_type = "Heavy vehicle"
		elif event.key() == QtCore.Qt.Key_3:
			self.target_type = "Light vehicle"
		elif event.key() == QtCore.Qt.Key_4:
			self.target_type = "Group of men"
		print(self.target_type)

	def test_method(self):
		print('Space key pressed')

if __name__ == '__main__':
	app = QApplication(sys.argv)

	demo = MainWindow()
	demo.show()

	sys.exit(app.exec_())
