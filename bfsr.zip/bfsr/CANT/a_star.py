from helpers import PriorityQueue, GridLocation, RasterGrid, check_colinear, line_of_sight
import sys
from typing import Dict, List, Optional
from shapely.geometry import LineString, MultiPoint
from math import sqrt
import time,os


def reconstruct_path(came_from: Dict[GridLocation, GridLocation],
                     start: GridLocation, goal: GridLocation) -> List[GridLocation]:
    current: GridLocation = goal
    path: List[GridLocation] = []
    while current != start:
        path.append(current)
        current = came_from[current]
    path.append(start) # optional
    path.reverse() # optional
    return path


point11 = []
def shorten_linestring(points: List[GridLocation], graph: RasterGrid):
    start_time = time.time()
    nb_points = len(points)

    filtered_points = []
    if nb_points > 2:
        start = points[0]
        end = points[1]
        filtered_points.append(start)

        for point in points[2:]:
            if line_of_sight(graph, start, point):
                end = point
            else:
                filtered_points.append(end)
                start = end
                end = point
        filtered_points.append(end)

        import rasterio
        ds = rasterio.open('/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/recassify.tif')
        ls_points = list(map(lambda point: ds.xy(point[1], point[0]), filtered_points))
        point11.append(ls_points)
        ls = LineString(ls_points)
        with open('/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/filtered_joints.txt', 'w') as f:
            f.write(ls.wkt)
    else:
        filtered_points = points.copy()

    end_time = time.time()
    print(f"shorten_linestring took {end_time - start_time}s")
    return filtered_points


def get_joints_from_path(path: List[GridLocation]):
    start_time = time.time()
    nb_points = len(path)

    joints = []
    if nb_points > 2:
        p1 = path[0]
        p2 = path[1]

        joints.append(p1)
        for p in path[2:]:
            if check_colinear(p1, p2, p):
                p2 = p
            else:
                joints.append(p2)
                p1 = p2
                p2 = p
        joints.append(p2)

        # import rasterio
        # ds = rasterio.open('recassify.tif')
        # ls_points = list(map(lambda point: ds.xy(point[1], point[0]), joints))
        # mp = MultiPoint(ls_points)
        # with open('joints.txt', 'w') as f:
        #     f.write(mp.wkt)
    else:
        joints = path.copy() 
    end_time = time.time()  
    print(f"get_joints_from_path took {end_time - start_time}s")
    return joints


def heuristic(a: GridLocation, b: GridLocation) -> float:
    (x1, y1) = a
    (x2, y2) = b
    dx = abs(x1 - x2)
    dy = abs(y1 - y2)
    return (dx + dy) + (sqrt(2) - 2) * min(dx, dy)
    # return abs(x1 - x2) + abs(y1 - y2)

def a_star_search(graph: RasterGrid, start: GridLocation, goal: GridLocation):

    if not (graph.passable(start) and graph.passable(goal) and graph.in_bounds(start) and graph.in_bounds(goal)):
        raise Exception("Invalid start and goal value")

    frontier = PriorityQueue()
    frontier.put(start, 0)
    came_from: Dict[GridLocation, Optional[GridLocation]] = {}
    cost_so_far: Dict[GridLocation, float] = {}
    came_from[start] = None
    cost_so_far[start] = 0
    
    while not frontier.empty():
        current: GridLocation = frontier.get()
        
        if current == goal:
            break
        
        for next in graph.neighbors(current):
            new_cost = cost_so_far[current] + graph.cost(current, next)
            if next not in cost_so_far or new_cost < cost_so_far[next]:
                cost_so_far[next] = new_cost
                priority = new_cost + heuristic(next, goal)
                frontier.put(next, priority)
                came_from[next] = current
    
    return came_from, cost_so_far

graph = RasterGrid("/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/recassify.tif", 2)


start = graph.raster.index(float(sys.argv[1]), float(sys.argv[2]))
goal = graph.raster.index(float(sys.argv[3]), float(sys.argv[4]))

start = start[::-1]
goal = goal[::-1]

print(start, goal)

came_from, cost_so_far = a_star_search(graph, start, goal)

path = reconstruct_path(came_from, start, goal)
points1 = []

with open("/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/temp.txt", "w") as f:
    points = []
    for location in path:
        points.append(graph.raster.xy(location[1], location[0]))
        points1.append(graph.raster.xy(location[1], location[0]))

    path_ls = LineString(points)
    f.write(path_ls.wkt)


joints = get_joints_from_path(path)
shortened_path = shorten_linestring(joints, graph)
print("hello")
print(shortened_path)

###########
print(point11)
with open("/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/path_points.txt", 'w') as f:
    for point in points1:
        f.write(str(point)+ os.linesep)
###########
##3d cesium
index_file = open("/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/index1.html", "w")
index_file.truncate()
index_file.close()

coord = []
with open('/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/filtered_joints.txt', 'r') as f:
    d = f.read()
    d = d.replace("LINESTRING (","")
    d = d.replace(")","")
    d = d.replace(", ",",0,")
    d = d.replace(" ",",")
    d = d+",0"
    coord.append(d)
    
with open("/home/bisag/.local/share/QGIS/QGIS3/profiles/default/python/plugins/single_path/index1.html", 'w') as f:
    mycarto_cords= ""
    # for point in points:
    #     mycarto_cords += str(point).replace("(","").replace(")",", 0,")
    # print(mycarto_cords)

    print("html::")
    str1 = '''
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Make the application on mobile take up the full browser screen and disable user scaling. -->
    <meta
    name="viewport"
    content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no"
    />
    <title>Index</title>
    <script src="/Build/Cesium/Cesium.js"></script>
    <link href="/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
    <style>
        html,
        body,
        #cesiumContainer {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
        }
    </style>
    <style>
        .cesium-viewer-animationContainer{
        display: none;
        }
        .cesium-viewer-bottom{
        display: none;
        }
    </style>

    </head>
    <body>
        <div id="cesiumContainer"></div>
    <script>

Cesium.Ion.defaultAccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJmOTQ1OWNhZS00NDY3LTQ3ZGItYTY5Ni03OTliOTgxMWVjYzIiLCJpZCI6NDAzMjIsImlhdCI6MTYwODYyNzkxNX0.yVW1tez7XbulKavYnEIswlgREug_3JxTj1ZXOuwKm2A";


var viewer = new Cesium.Viewer("cesiumContainer", {
  infoBox: false,
  selectionIndicator: false,
  shadows: true,
  shouldAnimate: true,
});


    
    var czml = [
    {
        id: "document",
        name: "CZML Geometries: Polyline",
        version: "1.0",
    },
    {
        id: "redLine",
        name: "Red line clamped to terain",
        polyline: {
        positions: {
            cartographicDegrees: ['''+coord[0]+'''],
        },
        material: {
            solidColor: {
            color: {
                rgba: [255, 0, 0, 255],
            },
            },
        },
        width: 5,
        clampToGround: true,
        show: true,
        zIndex: 0

        },
    },
    ];


    var dataSourcePromise = Cesium.CzmlDataSource.load(czml);
    viewer.dataSources.add(dataSourcePromise);
    viewer.zoomTo(dataSourcePromise);                        
    </script>
    </body>
    </html>

    '''

    f.write(str1)


