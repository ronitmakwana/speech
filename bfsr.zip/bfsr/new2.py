from new import first_function

first_function()
# 'This is the first function'

