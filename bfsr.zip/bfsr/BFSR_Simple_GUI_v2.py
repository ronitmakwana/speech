# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
import os, sys,time,cv2,easyocr
import threading
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer
from helpers import get_bfsr_location, get_target_location, clear_target_locations
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph
import SWHear
import warnings
import faulthandler
import sqlite3
import pyaudio
import pyqtgraph
import matplotlib.pyplot as plt


faulthandler.enable()

warnings.filterwarnings("ignore")
earac = SWHear.SWHear(device=7, rate=44100, updatesPerSecond=20)


FS = 44100 #Hz
CHUNKSZ = 1024 #samples

class MicrophoneRecorder():
    def __init__(self, signal):
        self.signal = signal
        self.p = pyaudio.PyAudio()
        self.stream = self.p.open(format=pyaudio.paInt16,
                            channels=1,
                            rate=FS,
                            input=True,
                            frames_per_buffer=CHUNKSZ)

    def read(self):
        data = self.stream.read(CHUNKSZ, exception_on_overflow=False)
        y = np.fromstring(data, 'int16')
        self.signal.emit(y)

    def close(self):
        self.stream.stop_stream()
        self.stream.close()
        self.p.terminate()

class SpectrogramWidget(pyqtgraph.PlotWidget):
    read_collected = QtCore.pyqtSignal(np.ndarray)
    def __init__(self):
        super(SpectrogramWidget, self).__init__()

        self.img = pyqtgraph.ImageItem()
        self.addItem(self.img)

        self.img_array = np.zeros((1000, int(CHUNKSZ/2+1)))

        # bipolar colormap
        pos = np.array([0., 1., 0.5, 0.25, 0.75])
        color = np.array([[0,255,255,255], [255,255,0,255], [0,0,0,255], (0, 0, 255, 255), (255, 0, 0, 255)], dtype=np.ubyte)
        cmap = pyqtgraph.ColorMap(pos, color)
        lut = cmap.getLookupTable(0.0, 1.0, 256)

        # set colormap
        self.img.setLookupTable(lut)
        self.img.setLevels([-50,40])

        # setup the correct scaling for y-axis
        freq = np.arange((CHUNKSZ/2)+1)/(float(CHUNKSZ)/FS)
        yscale = 1.0/(self.img_array.shape[1]/freq[-1])
        self.img.scale((1./FS)*CHUNKSZ, yscale)

        self.setLabel('left', 'Frequency', units='Hz')

        # prepare window for later use
        self.win = np.hanning(CHUNKSZ)
        
        self.show()

    def update_sprc(self, chunk):
        # normalized, windowed frequencies in data chunk
        spec = np.fft.rfft(chunk*self.win) / CHUNKSZ
        # get magnitude 
        psd = abs(spec)
        # convert to dB scale
        psd = 20 * np.log10(psd)

        # roll down one and replace leading edge with new data
        self.img_array = np.roll(self.img_array, -1, 0)
        self.img_array[-1:] = psd

        self.img.setImage(self.img_array, autoLevels=False)


class MicThread(QtCore.QThread):
    sig = QtCore.Signal(bytes)
    def __init__(self, sc):
        super(MicThread, self).__init__()
        self.sc = sc
        self.sig.connect(self.sc.append)
        self.running = True

    def run(self):
        try:
            while self.running:
                data = self.sc.stream.read(self.sc.CHUNK)
                self.sig.emit(data)
        except:
            (type, value, traceback) = sys.exc_info()
            sys.stdout.write(str(type))
            sys.stdout.write(str(value))
            sys.stdout.write(str(traceback.format_exc()))
            
    # def stop(self):
    #     sys.stdout.write('THREAD STOPPED')
    #     self.running = False

class StreamController(QtGui.QMainWindow):
    def __init__(self):
        super(StreamController, self).__init__()
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        # self.FORMAT = pyaudio.paInt16
        
    def setup_stream(self):
        # self.audio = pyaudio.PyAudio()
        
        
        # self.stream = self.earac.stream_startac(self)
        self.stream = earac.p.open(format=pyaudio.paInt16,  channels=1, rate=self.RATE, 
                            input=True, frames_per_buffer=self.CHUNK)
        self.micthread = MicThread(self)
        self.micthread.start()
        

    def append(self, vals):
        vals = np.frombuffer(vals, 'int16')
        c = self.CHUNK
        self.data[:-c] = self.data[c:]
        self.data[-c:] = vals
        
    # def breakdown_stream(self):
    #     self.micthread.terminate()
    #     self.stream.stop_stream()
    #     self.stream.close()
    #     self.audio.terminate()
    #     loop = QtCore.QEventLoop()
    #     QtCore.QTimer.singleShot(400, loop.quit)
    #     loop.exec_()
class Thread(QThread):
    sig = QtCore.Signal(bytes)
    changePixmap = pyqtSignal(QImage)

    def __init__(self, width, height):
        super().__init__()
        self.width, self.height = width, height

    def run(self):
        # self._stop_event = threading.Event()
        global kill_set_img_th
        cap = cv2.VideoCapture(0)
        # cap = cv2.VideoCapture('cdu_screen_video.mp4')
        while not kill_set_img_th:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = np.copy(frame)
                current_frame = cv2.resize(current_frame, (640, 480))
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = img.shape
                bytes_per_line = ch * w
                qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
                p = qt_img.scaled(self.width, self.height, QtCore.Qt.IgnoreAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)
            else:
                break
        cap.release()

    # def stop(self):
    #     self._stop_event.set()

'''
def capture_target_location(_easyocr, transformer):
    # For image of size 640x480
    global kill_ocr_thread
    roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
    while not kill_ocr_thread:
        if ocr_on_target_screen_flag:
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            get_target_location(roi, _easyocr, transformer)
            # time.sleep(15)

'''
    # self.grFFT.plotItem.showGrid(True, True, 0.7)
    #     self.grPCM.plotItem.showGrid(True, True, 0.7)
grFFT = 0
grPCM = 0
var = ""
# conn = sqlite3.connect('BFSR_PRED.db')
class Ui_MainWindow(QWidget):
    def __init__(self):
        super(Ui_MainWindow,self).__init__()
        
        
    def setupUi(self, MainWindow):
        global grFFT
        global grPCM
        MainWindow.setObjectName("MainWindow")

        screen_size = app.primaryScreen().size()
        self.window_width = screen_size.width() - 100
        self.window_height = screen_size.height() - 100

        MainWindow.setFixedSize(self.window_width, self.window_height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.keyPressEvent = self.keyPressEvent
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(10, 20, 201, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.target_capture_button = QtWidgets.QPushButton(self.centralwidget)
        self.target_capture_button.setGeometry(QtCore.QRect(210, 20, 141, 25))
        self.target_capture_button.setObjectName("pushButton_2")
        self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)
        self.target_type = ""

        vid_width = self.window_width - 20
        vid_height = self.window_height - 80
        self.cdu_screen_label.setGeometry(QtCore.QRect(10, 60,
                                                       vid_width,
                                                       vid_height))
        self.cdu_screen_label.setObjectName("graphicsView")
        self.clear_targets_button = QtWidgets.QPushButton(self.centralwidget)
        self.clear_targets_button.setGeometry(QtCore.QRect(350, 20, 141, 25))
        self.clear_targets_button.setObjectName("pushButton_3")
        self.show_on_map_button = QtWidgets.QPushButton(self.centralwidget)
        self.show_on_map_button.setGeometry(QtCore.QRect(490, 20, 141, 25))
        self.show_on_map_button.setObjectName("pushButton_4")
        self.label1 = QtWidgets.QLabel(self.centralwidget)

        # vid_width = self.window_width - 20
        # vid_height = self.window_height - 80
        self.label1.setGeometry(QtCore.QRect(920, 60, 880, 920))
        self.label1.setStyleSheet("border: 1px solid black;")
        self.label1.setObjectName("graphicsView")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        
        #**********************#
        
        # self.centralwidget = QtWidgets.QWidget(MainWindow)
        # self.centralwidget.setObjectName("centralwidget")
        
        pyqtgraph.setConfigOption('background', 'w') 
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.label1)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pbLevel = QtWidgets.QProgressBar(self.label1)
        self.pbLevel.setMaximum(1000)
        self.pbLevel.setProperty("value", 123)
        self.pbLevel.setTextVisible(False)
        self.pbLevel.setOrientation(QtCore.Qt.Vertical)
        self.pbLevel.setObjectName("pbLevel")
        self.horizontalLayout.addWidget(self.pbLevel)
        self.frame = QtWidgets.QFrame(self.label1)
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame.setObjectName("frame")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 50)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setObjectName("label_3")
        self.label_3.setGeometry(0,0, 880,22)
        
        # self.verticalLayout.addWidget(self.label_3)
        self.grPCMnew = PlotWidget(self.frame)
        self.grPCMnew.setObjectName("grPCMnew")
        # self.verticalLayout.addWidget(self.grPCMnew)
        self.grPCMnew.setGeometry(0,24, 438, 274)
        
        
        self.label_h = QtWidgets.QLabel(self.frame)
        self.label_h.setObjectName("label_3")
        self.label_h.setGeometry(440,24, 430,274)
        
        
        font = QtGui.QFont()
        self.prediction = QtWidgets.QLabel(self.frame)
        self.prediction.setGeometry(0,300,880, 50)
        
        font.setPointSize(20)
        self.prediction.setFont(font)
        self.prediction.setObjectName("prediction")
        
        # self.verticalLayout.addWidget(self.prediction,0, QtCore.Qt.AlignHCenter)
        
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setObjectName("label")
        self.label.setGeometry(0,352,880, 24)
        
        # self.verticalLayout.addWidget(self.label)
        # self.grFFT = PlotWidget(self.frame)
        # self.grFFT.setObjectName("grFFT")
        # self.verticalLayout.addWidget(self.grFFT)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.label_2.setGeometry(0,378,880, 500)
        self.label_2.setPixmap(QPixmap('11.jpeg'))
        # self.verticalLayout.addWidget(self.label_2)
        # self.grPCM = PlotWidget(self.frame)
        # self.grPCM.setObjectName("grPCM")
        # self.verticalLayout.addWidget(self.grPCM)
        self.horizontalLayout.addWidget(self.frame)
        MainWindow.setCentralWidget(self.centralwidget)
        
        pyqtgraph.setConfigOption('background', 'w')
        
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        
        # self.grFFT.plotItem.showGrid(True, True, 0.7)
        # self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.grPCMnew.plotItem.showGrid(True, True, 0.7)
        self.maxFFT = 0
        self.maxPCM = 0

        self.sc = StreamController()
        self.sc.setup_stream()

        #**********************#
        

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.target_capture_button.clicked.connect(self.target_capture_button_listener)
        self.clear_targets_button.clicked.connect(self.clear_targets_button_listener)

        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        self.video_display_th = Thread(880, 920)
        self.video_display_th.changePixmap.connect(self.set_image)
        self.video_display_th.setTerminationEnabled(True)
        self.video_display_th.start()
        
        # self.ear = SWHear.SWHear.stream_readchunk(self)
        # self.ear.stream_start()

    def update_streamplot(self):
        self.pdataitem.setData(self.sc.data)
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Cap BFSR Loc"))
        self.target_capture_button.setText(_translate("MainWindow", "Cap Tgt Loc"))
        self.clear_targets_button.setText(_translate("MainWindow", "Clear Tgts"))
        self.show_on_map_button.setText(_translate("MainWindow", "Show Map"))
        self.label.setText(_translate("MainWindow", "Spectrogram : "))
        self.label_3.setText(_translate("MainWindow", "Audacity Wav : "))
        self.prediction.setText(_translate("MainWindow", "<>"))
        # self.label_2.setText(_translate("MainWindow", "Raw Data (PCM):"))
        


    def update(self):
      
        # if not self.ear.data is None and not self.ear.fft is None:
            # pcmMax = np.max(np.abs(self.ear.data))
            # if pcmMax > self.maxPCM:
            #     self.maxPCM = pcmMax
            #     self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            # if np.max(self.ear.fft) > self.maxFFT:
            #     self.maxFFT = np.max(np.abs(self.ear.fft))
            #     self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
            #     self.grFFT.plotItem.setRange(yRange=[0, 1])
            # try:
            #     self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
            #     pass
            # except TypeError:
            #     self.pbLevel.setValue(0)
        self.prediction.setText(earac.final_prediction)
            # pen = pyqtgraph.mkPen(color='b')
            # self.grPCM.plot(self.ear.datax, self.ear.data, pen=pen, clear=True)
            # pen = pyqtgraph.mkPen(color='r')
            # self.grFFT.plot(self.ear.fftx, self.ear.fft / self.maxFFT, pen=pen, clear=True)
        pen = pyqtgraph.mkPen(color='b')         
        self.grPCMnew.plotItem.setRange(yRange=[-30000, 30000])
        self.grPCMnew.plot(self.sc.data, pen=pen, clear=True)
        global var
            # var = self.ear.final_prediction[0:14]
            # with open('file_audio.txt','w') as f:
            #     f.write(str(var))
                
      

        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY
    def capture_bfsr_location_button_listener(self):
        print("capture_bfsr_location_button function called")
        global current_frame
        # cv2.imwrite('logs/bfsr_location.png',current_frame)
        # For image of size 640x480
        roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_bfsr_location(roi, self._easyocr, self.transformer)
        

    def target_capture_button_listener(self):
        print("target_capture_button function called")
        # cv2.imwrite('logs/target_location.png',current_frame)
        
        roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_target_location(roi,self.target_type, self._easyocr, self.transformer) 

    def clear_targets_button_listener(self):
        print("clear_targets_button function called")
        clear_target_locations()
        

    @pyqtSlot(QImage)
    def set_image(self, image):
        
        self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))
        
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_1:
            self.target_type = "No sound"
        elif event.key() == QtCore.Qt.Key_2:
            self.target_type = "Heavy vehicle"
        elif event.key() == QtCore.Qt.Key_3:
            self.target_type = "Light vehicle"
        elif event.key() == QtCore.Qt.Key_4:
            self.target_type = "Group of men"
        print(self.target_type)
        
# cursor = conn.cursor()
# command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
# cursor.execute(command)
# comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
# cursor.execute(comm)
# cursor.close()
# conn.commit()
from pyqtgraph import PlotWidget


if __name__ == "__main__":
    
    # sys.stdout = open('stdout.txt', 'w')
    # sys.stderr = open('stderr.txt', 'w')

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    kill_set_img_th = False
    current_frame = True

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    
    w = SpectrogramWidget()
    w.read_collected.connect(w.update_sprc)

    mic = MicrophoneRecorder(w.read_collected)

    # time (seconds) between reads
    interval = FS/CHUNKSZ
    t = QtCore.QTimer()
    t.timeout.connect(mic.read)
    t.start(1000/interval) #QTimer takes ms
    
    
    ui.update()
    MainWindow.show()
    exit_status = app.exec_()
    kill_set_img_th = True
    sys.exit(exit_status)
