// Example package for Vosk Go bindings.
package test_simple
