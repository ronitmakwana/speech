Vosk library for Android

See for details https://alphacephei.com/vosk/android
